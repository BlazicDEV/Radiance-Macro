const BIOMES = [
  ["windy", "Windy"], ["snowy", "Snowy"], ["rainy", "Rainy"],
  ["sandstorm", "Sandstorm"], ["hell", "Hell"], ["starfall", "Starfall"],
  ["heaven", "Heaven"], ["corruption", "Corruption"], ["null", "Null"],
];

const LOCKED_BIOMES = [
  ["glitched", "Glitched"], ["cyberspace", "Cyberspace"], ["dreamspace", "Dreamspace"], ["singularity", "Singularity"],
];
const LOCKED_PING_BIOMES = new Set(LOCKED_BIOMES.map(b => b[0]));
const RARE_TIER = new Set(["singularity", "glitched", "cyberspace", "dreamspace"]);
const ALL_BIOMES = [...BIOMES, ...LOCKED_BIOMES];


// ---- in-app update log ----
const UPDATE_LOG = [
  {version:"1.0", type:"Stable Release", date:"Current release", title:"First public release", items:[
    "Radiance Macro is now presented as version 1.0.",
    "Blazing Sun has been removed from the supported biome list.",
    "Added an in-app Update Log so users can review the release history.",
    "Prepared a standalone Windows executable build workflow.",
    "Previous pre-release builds are labelled DevB (Development Build)."
  ], note:"AI was used for brainstorming and improving the development workflow, not for mindless prompting. Implementation, review, and project decisions remain deliberate."},
  {version:"DevB", type:"Development Build", date:"Previous build", title:"OCR and detection improvements", items:[
    "Combined Roblox Rich Presence log detection with optional on-screen OCR.",
    "Added diagnostics, session statistics, history, and CSV export.",
    "Expanded Discord webhook settings and per-biome notification controls."
  ]},
  {version:"DevB", type:"Development Build", date:"Earlier build", title:"UI and reliability work", items:[
    "Introduced the desktop interface and event activity feed.",
    "Added configurable local notifications.",
    "Improved configuration migration and error handling."
  ]}
];
function renderUpdateLog(){
  const host=document.getElementById('updateLogList');
  if(!host) return;
  host.innerHTML=UPDATE_LOG.map((u,i)=>`
    <article class="update-card ${i===0?'update-current':''}">
      <div class="update-top"><span class="update-version">${escapeHtml(u.version)}</span><span class="update-type">${escapeHtml(u.type)}</span></div>
      <div class="update-title">${escapeHtml(u.title)}</div>
      <div class="update-date">${escapeHtml(u.date)}</div>
      <ul>${u.items.map(item=>`<li>${escapeHtml(item)}</li>`).join('')}</ul>
      ${u.note?`<p class="update-note">${escapeHtml(u.note)}</p>`:''}
    </article>`).join('');
}

let state = { running: false, paused: false };

function api() {
  return window.pywebview && window.pywebview.api;
}

function switchView(name) {
  document.querySelectorAll('.rail-btn').forEach(b => b.classList.toggle('active', b.dataset.view === name));
  document.querySelectorAll('.view').forEach(v => v.classList.toggle('active', v.id === `view-${name}`));
}

document.querySelectorAll('.rail-btn').forEach(btn => {
  btn.addEventListener('click', async () => {
    switchView(btn.dataset.view);
    if (btn.dataset.view === 'stats' || btn.dataset.view === 'history') {
      try {
        const stats = await api().get_stats();
        renderStats(stats);
        renderHistory(stats);
      } catch (e) { /* ignore - poller will catch up */ }
    } else if (btn.dataset.view === 'icons') {
      buildIconAssignList();
    } else if (btn.dataset.view === 'biomes') {
      loadMentions();
    } else if (btn.dataset.view === 'mentions') {
      loadMentions();
    } else if (btn.dataset.view === 'updates') {
      renderUpdateLog();
    } else if (btn.dataset.view === 'detect') {
      loadOcrConfig();
      refreshDiagnostics();
    }
  });
});

function setOrb(mode) {
  const orb = document.getElementById('orb');
  orb.className = 'orb ' + mode;
}

function setStatusText(title, detail) {
  document.getElementById('statusTitle').textContent = title;
  document.getElementById('statusDetail').textContent = detail;
}

function setButtons({ running, paused }) {
  document.getElementById('btnStart').disabled = running;
  document.getElementById('btnPause').disabled = !running;
  document.getElementById('btnStop').disabled = !running;
  document.getElementById('btnPause').textContent = paused ? 'Resume' : 'Pause';
}

function addLog(message, isEvent) {
  const list = document.getElementById('logList');
  const empty = list.querySelector('.log-empty');
  if (empty) empty.remove();
  const row = document.createElement('div');
  row.className = 'log-row' + (isEvent ? ' event' : '');
  const t = new Date().toLocaleTimeString([], { hour12: false });
  row.innerHTML = `<span class="log-time">${t}</span><span class="log-msg"></span>`;
  row.querySelector('.log-msg').textContent = message;
  list.prepend(row);
}

// ---- bridge callbacks (called from Python) ----
window.radiance = {
  onStatus(status) {
    state.running = status === 'running' || status === 'paused' || status === 'waiting_for_roblox';
    state.paused = status === 'paused';
    setButtons(state);
    if (status === 'running') {
      setOrb('running'); setStatusText('Running', 'Watching Roblox for biome changes');
    } else if (status === 'paused') {
      setOrb('paused'); setStatusText('Paused', 'Detection paused');
    } else if (status === 'waiting_for_roblox') {
      setOrb('waiting'); setStatusText('Waiting for Roblox', 'Launch Sol\u2019s RNG to begin detection');
    } else {
      setOrb(''); setStatusText('Idle', 'Not watching for Roblox');
    }
  },
  onBiome(event, action) {
    const label = action === 'started' ? 'Biome started' : 'Biome ended';
    addLog(`${label} — ${event}`, true);
  },
  onLog(message) {
    addLog(message, false);
  },
  onStats(stats) {
    renderStats(stats);
    renderHistory(stats);
  },
};

// ---- control buttons ----
document.getElementById('btnStart').addEventListener('click', async () => {
  const res = await api().start_macro();
  if (!res.ok) {
    addLog(res.error, false);
    switchView('webhook');
  }
});
document.getElementById('btnPause').addEventListener('click', () => api().pause_macro());
document.getElementById('btnStop').addEventListener('click', () => api().stop_macro());

// ---- webhook list ----
function renderWebhookList(webhooks) {
  const list = document.getElementById('webhookList');
  list.innerHTML = '';
  if (!webhooks || webhooks.length === 0) {
    list.innerHTML = '<div class="log-empty">No webhooks yet — add one below.</div>';
    return;
  }
  webhooks.forEach((w, i) => {
    const row = document.createElement('div');
    row.className = 'webhook-row' + (w.enabled ? '' : ' disabled');
    row.innerHTML = `
      <label class="webhook-toggle">
        <input type="checkbox" ${w.enabled ? 'checked' : ''} data-idx="${i}" class="wh-toggle" />
      </label>
      <div class="webhook-info">
        <div class="webhook-name">${escapeHtml(w.name || 'Webhook')}</div>
        <div class="webhook-url">${escapeHtml(maskUrl(w.url))}</div>
      </div>
      <button class="webhook-remove" data-idx="${i}" title="Remove">
        <svg viewBox="0 0 24 24" width="14" height="14"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="1.6" fill="none" stroke-linecap="round"/></svg>
      </button>`;
    list.appendChild(row);
  });
  list.querySelectorAll('.wh-toggle').forEach(cb => {
    cb.addEventListener('change', async (e) => {
      const res = await api().toggle_webhook(parseInt(e.target.dataset.idx, 10));
      renderWebhookList(res.webhooks);
    });
  });
  list.querySelectorAll('.webhook-remove').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const idx = parseInt(e.currentTarget.dataset.idx, 10);
      const res = await api().remove_webhook(idx);
      renderWebhookList(res.webhooks);
    });
  });
}

function maskUrl(url) {
  if (!url) return '';
  const parts = url.split('/');
  const id = parts[parts.length - 2] || '';
  return `…/${id.slice(0, 6)}…/${'•'.repeat(10)}`;
}

function escapeHtml(str) {
  const d = document.createElement('div');
  d.textContent = str;
  return d.innerHTML;
}

document.getElementById('btnAddWebhook').addEventListener('click', async () => {
  const name = document.getElementById('newWebhookName').value.trim();
  const url = document.getElementById('newWebhookUrl').value.trim();
  const errEl = document.getElementById('webhookAddError');
  errEl.textContent = '';
  const res = await api().add_webhook(name, url);
  if (!res.ok) {
    errEl.textContent = res.error;
    return;
  }
  document.getElementById('newWebhookName').value = '';
  document.getElementById('newWebhookUrl').value = '';
  renderWebhookList(res.webhooks);
});

// ---- webhook meta form (private server / discord id) ----
document.getElementById('privateServer').addEventListener('change', async () => {
  await api().save_webhook_meta(document.getElementById('privateServer').value.trim());
});

document.getElementById('btnSaveWebhook').addEventListener('click', async () => {
  await api().save_webhook_meta(document.getElementById('privateServer').value.trim());
  const conf = document.getElementById('webhookSaved');
  conf.classList.add('show');
  setTimeout(() => conf.classList.remove('show'), 1600);
});

document.getElementById('username').addEventListener('change', (e) => {
  api().save_username(e.target.value.trim());
});

document.getElementById('localNotifToggle').addEventListener('change', (e) => {
  api().set_local_notifications(e.target.checked);
});

document.getElementById('btnTestNotif').addEventListener('click', () => {
  api().test_local_notification();
});

// ---- about links ----
document.querySelectorAll('[data-ext]').forEach(el => {
  el.addEventListener('click', (e) => {
    e.preventDefault();
    api().open_external(el.dataset.ext);
  });
});

// ---- icon assignment ----
async function buildIconAssignList() {
  const container = document.getElementById('iconAssignList');
  let availableIcons, assigned;
  try {
    [availableIcons, assigned] = await Promise.all([
      api().list_biome_icons(),
      api().get_biome_icons(),
    ]);
  } catch (e) {
    container.innerHTML = '<div class="stats-empty">Could not load icons.</div>';
    return;
  }

  container.innerHTML = '';
  ALL_BIOMES.forEach(([key, label]) => {
    const row = document.createElement('div');
    row.className = 'icon-row';
    const currentFile = assigned[key] || '';
    const previewSrc = currentFile ? `biome_icons/${currentFile}` : '';

    row.innerHTML = `
      ${previewSrc
        ? `<img class="icon-preview" src="${previewSrc}" alt="" />`
        : `<div class="icon-preview empty">—</div>`}
      <span class="icon-name">${label}</span>
      <select class="icon-select" data-key="${key}">
        <option value="">No icon</option>
        ${availableIcons.map(f => `<option value="${f}" ${f === currentFile ? 'selected' : ''}>${f}</option>`).join('')}
      </select>`;

    const select = row.querySelector('select');
    const preview = row.querySelector('.icon-preview');
    select.addEventListener('change', async () => {
      await api().set_biome_icon(key, select.value);
      if (select.value) {
        const img = document.createElement('img');
        img.className = 'icon-preview';
        img.src = `biome_icons/${select.value}`;
        preview.replaceWith(img);
      } else {
        const empty = document.createElement('div');
        empty.className = 'icon-preview empty';
        empty.textContent = '—';
        preview.replaceWith(empty);
      }
    });
    container.appendChild(row);
    enhanceSelect(select);
  });
}

// ---- biome alerts ----
const RARE_ORDER = [["glitched", "Glitched"], ["cyberspace", "Cyberspace"], ["dreamspace", "Dreamspace"], ["singularity", "Singularity"]];
const OTHER_BIOMES = BIOMES.filter(([k]) => k !== 'singularity');
const MODE_LABELS = { message: 'Message', ping: 'Ping', nothing: 'Nothing' };
let biomeModes = {};
let otherOpen = false;

function modeOf(key) {
  if (LOCKED_PING_BIOMES.has(key)) return 'ping';
  return biomeModes[key] || 'message';
}

function labelOfMention(list, id) {
  const hit = (list || []).find(x => x.id === id);
  return hit ? (hit.label || hit.id) : id;
}

function recipientsFor(key) {
  const own = mentionState.per_biome && mentionState.per_biome[key];
  if (own) {
    return {
      custom: true,
      users: (own.users || []).map(id => labelOfMention(mentionState.users, id)),
      roles: (own.roles || []).map(id => labelOfMention(mentionState.roles, id)),
    };
  }
  return {
    custom: false,
    users: mentionState.users.map(u => u.label || u.id),
    roles: mentionState.roles.map(r => r.label || r.id),
  };
}

function pingLineHtml(key) {
  const mode = modeOf(key);
  if (mode === 'nothing') return '<span class="ping-arrow">↳</span> <span class="ping-dim">Silent - no message is sent</span>';
  if (mode === 'message') return '<span class="ping-arrow">↳</span> <span class="ping-dim">Embed only - nobody is mentioned</span>';
  const r = recipientsFor(key);
  const chips = r.users.map(n => '<span class="ping-chip">@' + escapeHtml(n) + '</span>')
    .concat(r.roles.map(n => '<span class="ping-chip role">@' + escapeHtml(n) + '</span>'));
  if (!chips.length) {
    return '<span class="ping-arrow">↳</span> <span class="ping-warn">Nobody to ping yet - message only.</span> ' +
      '<button type="button" class="ping-link" data-goto="mentions">Add a player →</button>';
  }
  return '<span class="ping-arrow">↳</span> <span class="ping-dim">Pings</span> ' + chips.join('') +
    (r.custom ? ' <span class="ping-tag">custom list</span>' : '');
}

function biomeRow(key, label, locked) {
  const row = document.createElement('div');
  row.className = 'biome-card' + (locked ? ' locked' : '');
  row.dataset.key = key;
  const control = locked
    ? '<span class="biome-locked-badge" title="Always pings - this biome is too rare to mute">Ping · locked</span>'
    : '<div class="seg" role="radiogroup">' + ['message', 'ping', 'nothing'].map(m =>
        '<button type="button" class="seg-btn" role="radio" data-mode="' + m + '">' + MODE_LABELS[m] + '</button>').join('') + '</div>';
  row.innerHTML = '<span class="biome-name">' + escapeHtml(label) + '</span>' + control +
    '<div class="biome-ping-line"></div>';
  row.querySelectorAll('.seg-btn').forEach(btn => btn.addEventListener('click', () => {
    biomeModes[key] = btn.dataset.mode;
    api().save_biome_modes({ [key]: btn.dataset.mode });
    paintBiomeRow(row);
    updateOtherSummary();
  }));
  return row;
}

function paintBiomeRow(row) {
  const key = row.dataset.key;
  const mode = modeOf(key);
  row.querySelectorAll('.seg-btn').forEach(b => {
    const on = b.dataset.mode === mode;
    b.classList.toggle('on', on);
    b.setAttribute('aria-checked', on ? 'true' : 'false');
  });
  row.classList.toggle('silent', mode === 'nothing');
  row.querySelector('.biome-ping-line').innerHTML = pingLineHtml(key);
  row.querySelectorAll('.ping-link').forEach(l => l.addEventListener('click', () => {
    switchView('mentions');
    loadMentions();
  }));
}

function updateOtherSummary() {
  const tally = {};
  OTHER_BIOMES.forEach(([k]) => { const m = modeOf(k); tally[m] = (tally[m] || 0) + 1; });
  const parts = ['message', 'ping', 'nothing'].filter(m => tally[m]).map(m => tally[m] + ' ' + MODE_LABELS[m].toLowerCase());
  document.getElementById('otherBiomesSummary').textContent = OTHER_BIOMES.length + ' biomes · ' + parts.join(' · ');
}

function buildBiomeGrid(modes) {
  if (modes) biomeModes = Object.assign({}, modes);
  const rare = document.getElementById('biomeGridRare');
  const other = document.getElementById('biomeGrid');
  rare.innerHTML = '';
  other.innerHTML = '';
  RARE_ORDER.forEach(([key, label]) => rare.appendChild(biomeRow(key, label, LOCKED_PING_BIOMES.has(key))));
  OTHER_BIOMES.forEach(([key, label]) => other.appendChild(biomeRow(key, label, false)));
  renderBiomeView();
}

function renderBiomeView() {
  document.querySelectorAll('#view-biomes .biome-card').forEach(paintBiomeRow);
  updateOtherSummary();
}

document.getElementById('btnOtherBiomes').addEventListener('click', () => {
  otherOpen = !otherOpen;
  document.getElementById('biomeGrid').hidden = !otherOpen;
  document.getElementById('btnOtherBiomes').setAttribute('aria-expanded', otherOpen ? 'true' : 'false');
  document.getElementById('btnOtherBiomes').classList.toggle('open', otherOpen);
});

// ---- themed dropdown (replaces the white native <select> popup) ----
// The open list is moved to <body> and positioned with `fixed`, so no card or
// animated container can ever paint on top of it.
function closeAllDropdowns() {
  document.querySelectorAll('.dd.open').forEach(d => d._close && d._close());
}

function enhanceSelect(sel) {
  if (!sel) return;
  let wrap = sel._dd;
  if (!wrap) {
    wrap = document.createElement('div');
    wrap.className = 'dd';
    wrap.innerHTML = '<button type="button" class="dd-btn" aria-haspopup="listbox"><span class="dd-label"></span>' +
      '<svg class="chev" viewBox="0 0 24 24" width="14" height="14"><path d="M6 9l6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></button>';
    const menu = document.createElement('div');
    menu.className = 'dd-menu';
    menu.setAttribute('role', 'listbox');
    menu.hidden = true;
    sel.parentNode.insertBefore(wrap, sel);
    wrap.appendChild(sel);
    wrap.appendChild(menu);
    sel.classList.add('dd-native');
    sel._dd = wrap;
    wrap._menu = menu;
    const btn = wrap.querySelector('.dd-btn');

    wrap._close = () => {
      menu.hidden = true;
      menu.style.cssText = '';
      wrap.classList.remove('open');
      if (menu.parentNode !== wrap) wrap.appendChild(menu);
    };
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const willOpen = !wrap.classList.contains('open');
      closeAllDropdowns();
      if (!willOpen) return;
      const r = btn.getBoundingClientRect();
      // fixed + invisible BEFORE it enters <body>, so it can never stretch the page
      menu.style.cssText = 'position:fixed;left:0;top:0;visibility:hidden';
      document.body.appendChild(menu);
      menu.hidden = false;
      wrap.classList.add('open');
      wrap._openedAt = performance.now();
      const h = Math.min(232, menu.scrollHeight + 12);
      const below = window.innerHeight - r.bottom;
      const up = below < h + 14 && r.top > below;
      menu.style.visibility = 'visible';
      menu.style.left = r.left + 'px';
      menu.style.width = Math.max(r.width, 160) + 'px';
      menu.style.top = (up ? Math.max(8, r.top - h - 6) : r.bottom + 6) + 'px';
      const cur = menu.querySelector('.dd-item.sel');
      if (cur) menu.scrollTop = Math.max(0, cur.offsetTop - 40);  // not scrollIntoView: it scrolls the page and would close the list
    });
    btn.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') wrap._close();
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        const i = sel.selectedIndex + (e.key === 'ArrowDown' ? 1 : -1);
        if (i >= 0 && i < sel.options.length) { sel.selectedIndex = i; sel.dispatchEvent(new Event('change')); enhanceSelect(sel); }
      }
    });
  }
  const menu = wrap._menu;
  menu.innerHTML = '';
  Array.from(sel.options).forEach((o, i) => {
    const item = document.createElement('div');
    item.className = 'dd-item' + (i === sel.selectedIndex ? ' sel' : '');
    item.setAttribute('role', 'option');
    item.textContent = o.textContent;
    item.addEventListener('click', (e) => {
      e.stopPropagation();
      sel.selectedIndex = i;
      sel.dispatchEvent(new Event('change'));
      wrap._close();
      enhanceSelect(sel);
    });
    menu.appendChild(item);
  });
  const cur = sel.options[sel.selectedIndex];
  wrap.querySelector('.dd-label').textContent = cur ? cur.textContent : '';
}
document.addEventListener('click', closeAllDropdowns);
window.addEventListener('resize', closeAllDropdowns);
document.addEventListener('scroll', (e) => {
  if (e.target && e.target.nodeType === 1 && e.target.closest('.dd-menu')) return;  // the list scrolling itself
  const fresh = Array.from(document.querySelectorAll('.dd.open')).some(d => performance.now() - (d._openedAt || 0) < 400);
  if (!fresh) closeAllDropdowns();
}, true);

// ---- stats dashboard ----
function formatDuration(seconds) {
  seconds = Math.floor(seconds || 0);
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h) return `${h}h ${m}m`;
  if (m) return `${m}m ${s}s`;
  return `${s}s`;
}

document.getElementById('btnExportStats').addEventListener('click', async () => {
  const confirmEl = document.getElementById('exportConfirm');
  const errorEl = document.getElementById('exportError');
  confirmEl.classList.remove('show');
  errorEl.textContent = '';
  try {
    const res = await api().export_stats_csv();
    if (res.ok) {
      confirmEl.textContent = 'Saved';
      confirmEl.classList.add('show');
      setTimeout(() => confirmEl.classList.remove('show'), 1800);
    } else if (res.error !== 'cancelled') {
      errorEl.textContent = res.error || 'Could not export.';
    }
  } catch (e) {
    errorEl.textContent = 'Could not export.';
  }
});

function renderStats(stats) {
  const counts = stats.counts || {};
  const names = Object.keys(counts);
  const maxCount = Math.max(1, ...names.map(n => counts[n]));
  const rareCount = names
    .filter(n => RARE_TIER.has(biomeKeyFromLabel(n)))
    .reduce((sum, n) => sum + counts[n], 0);

  document.getElementById('statDuration').textContent = formatDuration(stats.elapsed_seconds);
  document.getElementById('statBiomeCount').textContent = names.length;
  document.getElementById('statRareCount').textContent = rareCount;
  const lt = document.getElementById('statLifetimeRare'); if (lt) lt.textContent = stats.lifetime_rare || 0;
  const cr = document.getElementById('statCrashes'); if (cr) cr.textContent = stats.crashes_7d || 0;

  const list = document.getElementById('statsList');
  if (!names.length) {
    list.innerHTML = '<div class="stats-empty">No biomes detected yet this session.</div>';
    return;
  }
  const ordered = names.sort((a, b) => counts[b] - counts[a]);
  list.innerHTML = ordered.map(name => {
    const key = biomeKeyFromLabel(name);
    const isRare = RARE_TIER.has(key);
    const pct = Math.max(6, Math.round((counts[name] / maxCount) * 100));
    return `
      <div class="stats-row${isRare ? ' rare' : ''}">
        <span class="stats-name">${escapeHtml(titleCase(name))}</span>
        <div class="stats-bar-track"><div class="stats-bar-fill" style="width:${pct}%"></div></div>
        <span class="stats-count">${counts[name]}×</span>
      </div>`;
  }).join('');
}

function biomeKeyFromLabel(name) {
  return (name || '').replace(/ /g, '_').toLowerCase();
}

function titleCase(str) {
  return (str || '').toLowerCase().replace(/\b\w/g, c => c.toUpperCase());
}

// ---- history timeline ----
function renderHistory(stats) {
  const timeline = document.getElementById('historyTimeline');
  const history = stats.history || [];
  if (!history.length) {
    timeline.innerHTML = '<div class="timeline-empty">No biome changes recorded yet.</div>';
    return;
  }
  const items = history.slice().reverse().map(h => {
    const key = biomeKeyFromLabel(h.event);
    const isRare = RARE_TIER.has(key);
    const t = new Date(h.ts * 1000).toLocaleTimeString([], { hour12: false });
    const verb = h.action === 'started' ? 'started' : 'ended';
    return `
      <div class="timeline-item${isRare ? ' rare' : ''}">
        <div class="timeline-time">${t}</div>
        <div class="timeline-label">${escapeHtml(titleCase(h.event))} ${verb}</div>
      </div>`;
  }).join('');
  timeline.innerHTML = items;
}
window.addEventListener('pywebviewready', async () => {
  try {
    const cfg = await api().get_config();
    const webhook = cfg.Webhook || {};
    document.getElementById('privateServer').value = webhook.private_server || '';
    document.getElementById('username').value = (cfg.Macro && cfg.Macro.roblox_username) || '';
    document.getElementById('localNotifToggle').checked = (cfg.Macro && cfg.Macro.local_notifications === 'true') || false;
    try {
      renderWebhookList(webhook.webhooks || []);
    } catch (e) {
      addLog('UI error (webhooks): ' + e.message, false);
    }
    try {
      buildBiomeGrid(cfg.Biomes || {});
      loadMentions();
    } catch (e) {
      addLog('UI error (biomes): ' + e.message, false);
    }
  } catch (e) {
    addLog('Failed to load config: ' + e.message, false);
  }
  try {
    const v = await api().get_version();
    document.getElementById('appTitle').textContent = 'Radiance Macro v' + v;
    document.getElementById('aboutVersion').textContent = 'v' + v;
    document.title = 'Radiance Macro v' + v;
  } catch (e) { /* cosmetic only */ }
  startEventPolling();
});

// ---- engine event polling (thread-safe: pulls from a queue instead of
// Python calling evaluate_js from a background thread, which hangs WebView2) ----
// ---- engine event polling (thread-safe: pulls from a queue instead of
// Python calling evaluate_js from a background thread, which hangs WebView2).
// Uses a self-rescheduling setTimeout rather than setInterval so calls
// can never stack up if one poll is slow to resolve. ----
let _pollingActive = false;
function startEventPolling() {
  if (_pollingActive) return;
  _pollingActive = true;
  const tick = async () => {
    try {
      const events = await api().poll_events();
      if (events && events.length) {
        events.forEach(ev => {
          if (ev.type === 'status') window.radiance.onStatus(ev.status);
          else if (ev.type === 'biome') window.radiance.onBiome(ev.event, ev.action);
          else if (ev.type === 'log') window.radiance.onLog(ev.message);
          else if (ev.type === 'stats') window.radiance.onStats(ev.stats);
        });
      }
    } catch (e) {
      // ignore transient bridge errors, keep polling
    } finally {
      setTimeout(tick, 500);
    }
  };
  setTimeout(tick, 500);
}

// ---- past sessions (History tab) ----
function fmtDur(sec) {
  sec = Math.floor(sec || 0);
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60);
  return h ? `${h}h ${String(m).padStart(2, '0')}m` : `${m}m`;
}
async function loadPastSessions() {
  const el = document.getElementById('pastSessions');
  if (!el) return;
  try {
    const r = await api().get_sessions();
    if (!r.sessions.length) {
      el.innerHTML = '<div class="stats-empty">No finished sessions yet — they appear here after you press Stop.</div>';
      return;
    }
    const rows = r.sessions.map(s => {
      const d = new Date(s.start * 1000).toLocaleString([], { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', hour12: false });
      return `<div class="stats-row${s.rare ? ' rare' : ''}"><span class="stats-name">${d}${s.recovered ? ' · recovered' : ''}</span>` +
        `<span class="stats-count">${fmtDur(s.duration)}</span><span class="stats-count">${s.biomes} biomes</span><span class="stats-count">${s.rare} rare</span></div>`;
    }).join('');
    el.innerHTML = `<p class="hint" style="margin:0 0 12px">${r.session_count} sessions · ${r.total_hours} h tracked · ${r.total_rare} rare · ${r.rare_per_hour} rare/h</p>` + rows;
  } catch (e) {
    el.innerHTML = '<div class="stats-empty">Could not load past sessions.</div>';
  }
}
document.querySelector('.rail-btn[data-view="history"]').addEventListener('click', loadPastSessions);

// ---- mentions (multiple users + roles, overridable per biome) ----
let mentionState = { users: [], roles: [], per_biome: {} };

async function loadMentions() {
  try {
    const data = await api().get_mentions();
    mentionState = {
      users: (data && data.users) || [],
      roles: (data && data.roles) || [],
      per_biome: (data && data.per_biome) || {},
    };
  } catch (e) {
    mentionState = { users: [], roles: [], per_biome: {} };
  }
  renderMentionUsers();
  renderMentionRoles();
  renderMentionBiomes();
  renderBiomeView();
}

function mentionRemoveIcon() {
  return '<svg viewBox="0 0 24 24" width="14" height="14"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="1.6" fill="none" stroke-linecap="round"/></svg>';
}

function renderMentionList(containerId, items, onRemove) {
  const el = document.getElementById(containerId);
  el.innerHTML = '';
  if (!items.length) {
    el.innerHTML = '<div class="log-empty">Nothing here yet - add an ID below.</div>';
    return;
  }
  items.forEach((item, i) => {
    const row = document.createElement('div');
    row.className = 'webhook-row';
    row.innerHTML = '<div class="webhook-info"><div class="webhook-name">' +
      escapeHtml(item.label || 'Unnamed') + '</div><div class="webhook-url">' +
      escapeHtml(item.id) + '</div></div>';
    row.appendChild(mentionRemoveButton(i));
    el.appendChild(row);
  });
  el.querySelectorAll('.webhook-remove').forEach(btn => {
    btn.addEventListener('click', () => onRemove(parseInt(btn.dataset.idx, 10)));
  });
}

function mentionRemoveButton(i) {
  const btn = document.createElement('button');
  btn.className = 'webhook-remove';
  btn.dataset.idx = i;
  btn.title = 'Remove';
  btn.innerHTML = mentionRemoveIcon();
  return btn;
}

function renderMentionUsers() {
  renderMentionList('mentionUserList', mentionState.users, async (idx) => {
    const next = mentionState.users.slice();
    next.splice(idx, 1);
    await api().save_mention_users(next);
    await loadMentions();
  });
}

function renderMentionRoles() {
  renderMentionList('mentionRoleList', mentionState.roles, async (idx) => {
    const next = mentionState.roles.slice();
    next.splice(idx, 1);
    await api().save_mention_roles(next);
    await loadMentions();
  });
}

function mentionChip(kind, id, label, checked) {
  return '<label class="mention-chip"><input type="checkbox" data-kind="' + kind +
    '" data-id="' + escapeHtml(id) + '" ' + (checked ? 'checked' : '') +
    ' /><span>' + escapeHtml(label) + '</span></label>';
}

function renderMentionBiomes() {
  const el = document.getElementById('mentionBiomeList');
  el.innerHTML = '';
  [...RARE_ORDER, ...OTHER_BIOMES].forEach(([key, label]) => {
    const override = mentionState.per_biome[key];
    const custom = !!override;
    const chips = [];
    if (custom) {
      mentionState.users.forEach(u => {
        const on = (override.users || []).indexOf(u.id) !== -1;
        chips.push(mentionChip('users', u.id, u.label || u.id, on));
      });
      mentionState.roles.forEach(r => {
        const on = (override.roles || []).indexOf(r.id) !== -1;
        chips.push(mentionChip('roles', r.id, r.label || r.id, on));
      });
      if (!chips.length) {
        chips.push('<span class="mention-inherit">No users or roles configured yet.</span>');
      }
    } else {
      chips.push('<span class="mention-inherit">Inherits all users and roles</span>');
    }

    const row = document.createElement('div');
    row.className = 'mention-biome-row';
    row.innerHTML = '<div class="mention-biome-head"><span class="mention-biome-name">' +
      escapeHtml(label) + '</span><label class="mention-custom"><input type="checkbox" ' +
      (custom ? 'checked' : '') + ' /> Customize</label></div>' +
      '<div class="mention-chips">' + chips.join('') + '</div>';

    row.querySelector('.mention-custom input').addEventListener('change', async () => {
      const next = JSON.parse(JSON.stringify(mentionState.per_biome));
      if (next[key]) {
        delete next[key];
      } else {
        next[key] = {
          users: mentionState.users.map(u => u.id),
          roles: mentionState.roles.map(r => r.id),
        };
      }
      await api().save_mention_per_biome(next);
      mentionState.per_biome = next;
      renderMentionBiomes();
      renderBiomeView();
    });

    row.querySelectorAll('.mention-chip input').forEach(cb => {
      cb.addEventListener('change', async () => {
        const next = JSON.parse(JSON.stringify(mentionState.per_biome));
        const entry = next[key] || { users: [], roles: [] };
        const kind = cb.dataset.kind;
        const id = cb.dataset.id;
        const list = (entry[kind] || []).slice();
        const at = list.indexOf(id);
        if (cb.checked && at === -1) list.push(id);
        if (!cb.checked && at !== -1) list.splice(at, 1);
        entry[kind] = list;
        next[key] = entry;
        await api().save_mention_per_biome(next);
        mentionState.per_biome = next;
        renderBiomeView();
      });
    });

    el.appendChild(row);
  });
}

document.getElementById('btnAddMentionUser').addEventListener('click', async () => {
  const idEl = document.getElementById('newMentionUserId');
  const labelEl = document.getElementById('newMentionUserLabel');
  const errEl = document.getElementById('mentionUserError');
  errEl.textContent = '';
  const id = idEl.value.trim();
  if (!/^\d+$/.test(id)) {
    errEl.textContent = 'A Discord user ID is all digits.';
    return;
  }
  const payload = mentionState.users.concat([{ id: id, label: labelEl.value.trim() }]);
  await api().save_mention_users(payload);
  idEl.value = '';
  labelEl.value = '';
  await loadMentions();
});

document.getElementById('btnAddMentionRole').addEventListener('click', async () => {
  const idEl = document.getElementById('newMentionRoleId');
  const labelEl = document.getElementById('newMentionRoleLabel');
  const errEl = document.getElementById('mentionRoleError');
  errEl.textContent = '';
  const id = idEl.value.trim();
  if (!/^\d+$/.test(id)) {
    errEl.textContent = 'A Discord role ID is all digits.';
    return;
  }
  const payload = mentionState.roles.concat([{ id: id, label: labelEl.value.trim() }]);
  await api().save_mention_roles(payload);
  idEl.value = '';
  labelEl.value = '';
  await loadMentions();
});

// ---- OCR settings + diagnostic (Detection tab) ----
function ocrFields() {
  return {
    enabled: document.getElementById('ocrToggle').checked,
    left: parseFloat(document.getElementById('ocrLeft').value) / 100,
    top: parseFloat(document.getElementById('ocrTop').value) / 100,
    width: parseFloat(document.getElementById('ocrWidth').value) / 100,
    height: parseFloat(document.getElementById('ocrHeight').value) / 100,
    interval: parseFloat(document.getElementById('ocrInterval').value),
  };
}

async function loadOcrConfig() {
  try {
    const c = await api().get_ocr_config();
    document.getElementById('ocrToggle').checked = !!c.enabled;
    document.getElementById('ocrLeft').value = Math.round(c.left * 100);
    document.getElementById('ocrTop').value = Math.round(c.top * 100);
    document.getElementById('ocrWidth').value = Math.round(c.width * 100);
    document.getElementById('ocrHeight').value = Math.round(c.height * 100);
    document.getElementById('ocrInterval').value = c.interval;
  } catch (e) { /* ignore */ }
}

async function saveOcr(extra) {
  const errEl = document.getElementById('ocrError');
  errEl.textContent = '';
  try {
    const res = await api().save_ocr_config(Object.assign(ocrFields(), extra || {}));
    if (!res.ok) { errEl.textContent = res.error || 'Could not save.'; return false; }
    await loadOcrConfig();
    return true;
  } catch (e) {
    errEl.textContent = 'Could not save.';
    return false;
  }
}

document.getElementById('ocrToggle').addEventListener('change', () => saveOcr());
document.getElementById('btnOcrSave').addEventListener('click', async () => {
  if (await saveOcr({ calibrated: true, validated: true })) {
    const conf = document.getElementById('ocrSaved');
    conf.classList.add('show');
    setTimeout(() => conf.classList.remove('show'), 1600);
  }
});
document.getElementById('btnOcrAuto').addEventListener('click', async () => {
  if (await saveOcr({ calibrated: false, auto: true })) {
    document.getElementById('ocrResult').textContent = 'Auto zone on: the macro will find the biome text again by itself after Start.';
    document.getElementById('ocrPreview').hidden = true;
  }
});
document.getElementById('btnOcrFind').addEventListener('click', async () => {
  const out = document.getElementById('ocrResult');
  const img = document.getElementById('ocrPreview');
  const errEl = document.getElementById('ocrError');
  errEl.textContent = '';
  out.textContent = 'Minimizing and scanning the whole game window…';
  try {
    const r = await api().find_ocr_zone();
    if (r.image) { img.src = r.image; img.hidden = false; } else { img.hidden = true; }
    if (r.ok) {
      await loadOcrConfig();
      out.textContent = 'Found “' + titleCase(r.match) + '” - zone saved (red box). Turn OCR on if it is not already.';
    } else {
      out.textContent = (r.seen && r.seen.length) ? 'OCR saw on screen: ' + r.seen.join(' · ') : '';
      errEl.textContent = r.error || 'Nothing found.';
    }
  } catch (e) {
    out.textContent = '';
    errEl.textContent = 'Scan failed.';
  }
});

document.getElementById('btnOcrTest').addEventListener('click', async () => {
  const out = document.getElementById('ocrResult');
  const img = document.getElementById('ocrPreview');
  const errEl = document.getElementById('ocrError');
  errEl.textContent = '';
  out.textContent = 'Reading…';
  if (!(await saveOcr())) { out.textContent = ''; return; }
  try {
    const r = await api().test_ocr();
    if (r.image) { img.src = r.image; img.hidden = false; } else { img.hidden = true; }
    if (r.error) { out.textContent = ''; errEl.textContent = r.error; return; }
    const seen = r.text ? '“' + r.text + '”' : '(nothing readable)';
    out.textContent = 'OCR read: ' + seen + ' → ' +
      (r.match ? 'matched ' + titleCase(r.match) + ' (' + Math.round(r.score * 100) + '%)' : 'no biome matched');
  } catch (e) {
    out.textContent = '';
    errEl.textContent = 'Test failed.';
  }
});

function ago(ts) {
  if (!ts) return '—';
  const s = Math.max(0, Math.round(Date.now() / 1000 - ts));
  if (s < 60) return s + 's ago';
  if (s < 3600) return Math.floor(s / 60) + 'm ago';
  return Math.floor(s / 3600) + 'h ago';
}

function diagRow(label, value, level) {
  return '<div class="diag-row"><span class="diag-dot ' + (level || '') + '"></span>' +
    '<span class="diag-key">' + escapeHtml(label) + '</span>' +
    '<span class="diag-val">' + escapeHtml(value) + '</span></div>';
}

async function refreshDiagnostics() {
  const el = document.getElementById('diagList');
  try {
    const d = await api().get_diagnostics();
    const rows = [];
    rows.push(diagRow('Macro', d.running ? (d.paused ? 'paused' : 'running') : 'stopped', d.running ? 'ok' : ''));
    rows.push(diagRow('Roblox', d.roblox ? 'detected (' + d.roblox + ')' : 'not detected', d.roblox ? 'ok' : 'warn'));
    if (d.screen) {
      const q = d.screen.h >= 2000 ? '4K' : (d.screen.h >= 1300 ? '1440p' : (d.screen.h >= 1000 ? '1080p' : d.screen.h + 'p'));
      rows.push(diagRow('Game window', d.screen.w + '×' + d.screen.h + ' (' + q + ')' + (d.screen.scale ? ' · Windows scaling ' + Math.round(d.screen.scale * 100) + '%' : ''), 'ok'));
    }
    rows.push(diagRow('Log file', d.log_path || 'none yet', d.log_path ? 'ok' : 'warn'));
    {
      const lagTxt = (typeof d.log_lag === 'number') ? ' · delay ' + Math.max(0, d.log_lag).toFixed(1) + 's' : '';
      const lagBad = typeof d.log_lag === 'number' && (d.log_lag > 5 || d.log_lag < -5);
      rows.push(diagRow('Source 1 · Roblox log (F9 feed)', d.last_rpc ? titleCase(d.last_rpc.event) + ' · ' + ago(d.last_rpc.ts) + lagTxt : (d.log_path ? 'listening…' : 'no log yet'), lagBad ? 'warn' : (d.log_path ? 'ok' : 'warn')));
      if (lagBad) rows.push(diagRow('', 'PC clock looks offset - sync Windows time', 'warn'));
      if (d.log_check) {
        rows.push(diagRow('Log check (every 2 s)', d.log_check.event ? titleCase(d.log_check.event) + ' · checked ' + d.log_check.age.toFixed(0) + 's ago' : 'no biome line yet', d.log_check.event ? 'ok' : 'warn'));
      }
      if (typeof d.log_idle_s === 'number') {
        const quiet = d.log_idle_s >= 30;
        rows.push(diagRow('Log activity', quiet ? 'Roblox wrote nothing for ' + Math.round(d.log_idle_s) + 's (paused, loading or minimized?)' : 'Roblox wrote ' + d.log_idle_s.toFixed(1) + 's ago', quiet ? 'warn' : 'ok'));
      }
    }
    rows.push(diagRow('Last Rich Presence', d.last_rpc ? titleCase(d.last_rpc.event) + ' · ' + ago(d.last_rpc.ts) : 'nothing received yet', d.last_rpc ? 'ok' : 'warn'));
    rows.push(diagRow('Current biome', d.current ? titleCase(d.current) : '—', ''));
    (d.console || []).slice(0, 5).forEach((c, i) => {
      rows.push(diagRow(i === 0 ? 'Console feed (like F9)' : '', (c.time ? c.time + '  ' : '') + titleCase(c.event), i === 0 ? 'ok' : ''));
    });
    rows.push(diagRow('Discord queue', d.queue + ' pending', d.queue > 3 ? 'warn' : 'ok'));
    (d.webhooks || []).forEach(w => {
      const state = !w.enabled ? 'disabled' : (w.ok === null ? 'not used yet' : (w.ok ? 'OK · ' + ago(w.ts) : 'FAILED · ' + w.detail));
      rows.push(diagRow('Webhook · ' + w.name, state, !w.enabled ? '' : (w.ok === null ? '' : (w.ok ? 'ok' : 'bad'))));
    });
    const o = d.ocr || {};
    let ocrState = 'off';
    let lvl = '';
    if (o.available === false) { ocrState = 'module missing'; lvl = 'bad'; }
    else if (o.enabled && o.error) { ocrState = o.error; lvl = 'bad'; }
    else if (o.enabled && o.auto && !o.calibrated) { ocrState = 'searching for the biome text…'; }
    else if (o.enabled && o.ts) { ocrState = (o.match ? titleCase(o.match) : 'no match') + ' · ' + ago(o.ts) + (o.calibrated ? (o.validated ? ' · zone verified by the log' : ' · zone not verified yet (confirms the log only)') : ''); lvl = 'ok'; }
    else if (o.enabled) { ocrState = 'on, waiting for first read'; }
    rows.push(diagRow('Source 2 · OCR', ocrState, lvl));
    if (o.enabled && o.ts && !o.error) {
      rows.push(diagRow('OCR speed', (o.reused ? 'no change on screen (skipped)' : (o.ms || 0) + ' ms per read') +
        (o.path ? ' · ' + (o.path === 'fast' ? 'direct engine' : 'winocr fallback') : '') + (o.variant ? ' · ' + o.variant : ''), 'ok'));
    }
    const sc = d.sources || {};
    if (sc.rpc || sc.ocr) {
      rows.push(diagRow('Who saw it first', 'log ' + ((sc.rpc || {}).first || 0) + ' · OCR ' + ((sc.ocr || {}).first || 0), ''));
    }
    el.innerHTML = rows.join('');
  } catch (e) {
    el.innerHTML = '<div class="stats-empty">Could not load diagnostic.</div>';
  }
}
setInterval(() => {
  const v = document.getElementById('view-detect');
  if (v && v.classList.contains('active') && api()) refreshDiagnostics();
}, 2000);

// ---- welcome splash: removed from the DOM once it has faded out ----
(function () {
  const w = document.getElementById('welcome');
  if (!w) return;
  const done = () => { if (w.parentNode) w.remove(); };
  w.addEventListener('animationend', (e) => { if (e.target === w && e.animationName === 'welcomeOut') done(); });
  w.addEventListener('click', () => { w.classList.add('skip'); setTimeout(done, 450); });
  setTimeout(done, 5000); // safety net
})();
