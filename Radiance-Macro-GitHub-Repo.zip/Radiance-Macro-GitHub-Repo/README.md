# Radiance Macro

Radiance Macro is a Windows utility project by [BlazicDEV](https://github.com/BlazicDEV). This repository contains the public source, build scripts, UI assets, tests, and the project website.

## Repository layout

- `app.py`, `engine.py`, `ocr.py`, `notify.py` — application and engine code
- `ui/` — local application interface and assets
- `tests/` — project tests and fixtures
- `build.py`, `build.bat` — Windows executable build helpers
- `config.ini.example` — example configuration only; add your own settings locally
- `docs/index.html` — static project website for GitHub Pages

## Run from source

1. Install a supported Python 3 version on Windows.
2. Open a terminal in this folder.
3. Install runtime dependencies: `python -m pip install -r requirements.txt`.
4. Copy `config.ini.example` to `config.ini` and edit your local settings. Do not commit `config.ini` or real webhook URLs.
5. Start the app with `python app.py`.

## Build the Windows executable

On Windows, run `build.bat` or use `python build.py`. The build uses PyInstaller to create a standalone executable. Test the output on a clean Windows environment before distributing it. Some systems may require the Microsoft Edge WebView2 Runtime.

## Publish the website with GitHub Pages

1. Create a GitHub repository named `Radiance-Macro` under the `BlazicDEV` account.
2. Upload the contents of this folder to the repository root (not the enclosing ZIP folder).
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/docs`, then save.
6. Wait for the Pages deployment to finish. The website should appear at `https://blazicdev.github.io/Radiance-Macro/`.

The website links point to `https://github.com/BlazicDEV/Radiance-Macro` and its Releases page, so create that repository before publishing the site. If you choose a different repository name or owner, update the links in `docs/index.html`.

## Publish a release

1. Build and test the executable on Windows.
2. In GitHub, open **Releases → Draft a new release**.
3. Create a version tag such as `v1.0.0`, add a factual changelog, and attach the tested executable and/or source archive.
4. Publish the release.
5. Keep the website's version information consistent with the actual published assets.

## Safety and privacy

- Never commit `config.ini`, personal webhook URLs, passwords, or tokens.
- `config.ini.example` should contain placeholders only.
- Do not claim that an executable is tested or safe until it has been verified.

## Creator

- GitHub: https://github.com/BlazicDEV
- YouTube: https://youtube.com/@iiblazicxc

See `COPYING` for the license.
