"""
Radiance Macro - Detection Engine
==================================
External, read-only Sol's RNG biome/event detector for Roblox.

Detection method: tails Roblox's own local log file and watches for the
SetRichPresence events Roblox writes for Discord Rich Presence integration.
No memory reading, no process injection, no game-file modification -
purely reads a log file Roblox already produces on disk. This is the same
external approach used by other allowed Sol's RNG tools (auto-fish,
auto-pop, etc).

This engine is derived from maxstellar's Biome Macro (GPLv3):
https://github.com/maxstellar/maxstellar-Biome-Macro
Original creator: maxstellar. Contributors: dannw, yeswe.
Redistributed and modified here under GPLv3 - see COPYING.
"""

import os
import re
import sys
import json
import time
import queue
import shutil
import threading
import configparser
import psutil
from discord_webhook import DiscordWebhook, DiscordEmbed

try:
    import notify
except ImportError:
    notify = None
try:
    import ocr as ocr_mod
except ImportError:
    ocr_mod = None

APP_NAME = "Radiance Macro"
APP_VERSION = "1.0"  # public release; earlier development builds are labelled DevB
# Discord embeds require a publicly reachable URL for avatars/thumbnails -
# a local file path won't work. Host assets/radiance_mark.png somewhere
# (GitHub raw, imgur, your own CDN) and put that URL here before shipping.
FOOTER_ICON = ""  # e.g. "https://raw.githubusercontent.com/<you>/radiance-macro/main/assets/radiance_mark.png"

VERSIONS_DIR = os.path.expandvars(r"%localappdata%\Roblox\Versions")
LOG_DIR = os.path.expandvars(r"%localappdata%\Roblox\logs")
PACKAGES_PATH = os.path.expandvars(r"%localappdata%\Packages")
# Must resolve the same way whether running from source or from a
# PyInstaller-built EXE. sys._MEIPASS is the temp extraction dir
# PyInstaller uses at runtime for --onefile builds; app.py's UI_INDEX
# uses the identical pattern, so this stays consistent with where the
# bundled ui/ folder (and ui/biome_icons/ inside it) actually lands.
BIOME_ICONS_DIR = os.path.join(
    getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__))),
    "ui", "biome_icons",
)

# Biome roster (per user confirmation, Sept 2026 - Pumpkin Moon, Graveyard,
# Blood Rain, Aurora, and Eggland were removed from the game and are no
# longer tracked).
# Standard (10): Normal, Windy, Snowy, Rainy, Sandstorm, Hell, Starfall, Heaven, Corruption, Null
# Rare (4): Glitched, Dreamspace, Cyberspace, Singularity
BIOME_COLORS = {
    "NORMAL": 0xFFFFFF,
    "WINDY": 0x91F7FF,
    "SNOWY": 0xC4F5F6,
    "RAINY": 0x4385FF,
    "SANDSTORM": 0xF4C27C,
    "HELL": 0x5C1219,
    "STARFALL": 0x6784E0,
    "HEAVEN": 0xF7E27A,
    "CORRUPTION": 0x9042FF,
    "NULL": 0x000000,
    "GLITCHED": 0x65FF65,
    "DREAMSPACE": 0xFF7DFF,
    "CYBERSPACE": 0x00FFD1,
    "SINGULARITY": 0x6B21E8,  # boosted from near-black so the embed's accent bar is actually visible
}
BIOME_COLORS.update({
    "AURORA": 0x00FA9A,
    "GRAVEYARD": 0x2F4F4F,
    "THE CITADEL OF ORDERS": 0xFFD700,
})
# Real durations in seconds (from SolRich's table): used only as a safety net, never to end a biome early.
BIOME_DURATIONS = {
    "WINDY": 120, "SNOWY": 120, "RAINY": 120, "SANDSTORM": 650, "HELL": 666, "STARFALL": 600,
    "HEAVEN": 240, "CORRUPTION": 650, "NULL": 99, "GLITCHED": 164, "DREAMSPACE": 192,
    "CYBERSPACE": 720, "SINGULARITY": 1200,
}
_HOVER_ALIASES = {
    "SAND STORM": "SANDSTORM", "GLITCH": "GLITCHED", "DREAM SPACE": "DREAMSPACE",
    "CYBER SPACE": "CYBERSPACE", "CITADEL OF ORDERS": "THE CITADEL OF ORDERS",
}
_HOVER_IGNORE = {"SOL'S RNG", "SOLS RNG", "SOL RNG", "EON", "EON 1", "EON-1", "PLAYING", "IN GAME",
                 "LOBBY", "THE WINDOW", "BY THE WINDOW", "UNKNOWN", "LOADING", "MENU"}
_RE_LARGE_HOVER = re.compile(r'"largeImage"\s*:\s*\{[^}]*?"hoverText"\s*:\s*"([^"]+)"', re.I)
_RE_ANY_HOVER = re.compile(r'"hoverText"\s*:\s*"([^"]+)"', re.I)
_RE_SMALL_IMAGE = re.compile(r'"smallImage"\s*:\s*\{[^}]*\}', re.I)   # the "Sol\' RNG" game logo, never a biome


def normalize_biome(text):
    """Game text -> our canonical biome name ('Sand Storm' -> 'SANDSTORM'). A name we do
    not know yet (a new biome) is kept, so it is reported instead of silently lost;
    only texts that are clearly not a biome are dropped."""
    t = " ".join((text or "").strip().upper().split())
    if t == "BLAZING SUN":
        return None  # removed from the current game roster; ignore stale log/HUD text
    if not (2 <= len(t) <= 30) or t in _HOVER_IGNORE or re.sub(r"[^A-Z]", "", t) in ("SOLSRNG", "SOLRNG"):
        return None
    if t in _HOVER_ALIASES:
        return _HOVER_ALIASES[t]
    if t in BIOME_COLORS:
        return t
    compact = t.replace(" ", "")
    for k in BIOME_COLORS:
        if k.replace(" ", "") == compact:
            return k
    return t if all(c.isalnum() or c in " '-" for c in t) else None


def parse_rpc_line(line):
    """Biome announced by one Roblox log line, or None. Tolerant of spacing, key order
    and extra fields: the game's Rich Presence line has changed shape before."""
    if "hoverText" not in line or ("[BloxstrapRPC]" not in line and "SetRichPresence" not in line):
        return None
    m = _RE_LARGE_HOVER.search(line)
    if m:
        return normalize_biome(m.group(1))
    for m in _RE_ANY_HOVER.finditer(_RE_SMALL_IMAGE.sub("", line)):
        ev = normalize_biome(m.group(1))
        if ev:
            return ev
    return None


DEFAULT_ACCENT = 0xD4AF37  # Radiance gold, used when a biome has no defined color

# Short atmospheric line shown under the biome title in Discord embeds.
# Purely cosmetic flavor text - biomes without an entry fall back to a
# generic line built from the biome name.
BIOME_FLAVOR = {
    "NORMAL": "Clear skies, nothing unusual.",
    "WINDY": "The air stirs.",
    "SNOWY": "Frost settles over the field.",
    "RAINY": "A steady rain begins to fall.",
    "SANDSTORM": "Visibility drops to nothing.",
    "HELL": "The sky burns red.",
    "STARFALL": "Streaks of light tear across the dark.",
    "HEAVEN": "Golden light breaks through the clouds.",
    "CORRUPTION": "Something has taken hold of the land.",
    "NULL": "Color drains from the world.",
    "GLITCHED": "Reality stutters and tears.",
    "DREAMSPACE": "The world folds into something unreal.",
    "CYBERSPACE": "Static and code flood the sky.",
    "SINGULARITY": "All things bend toward the center.",
}

# Per-biome icon assignment lives in Config's [BiomeIcons] section (set via
# the in-app Icons tab) rather than a hardcoded dict, since the icons are
# local files the user uploaded and assigned visually. See
# DetectionEngine._send_biome_webhook for how the file gets attached.

# Biomes whose ping mode is locked to "ping" - cannot be changed by the user.
# These are the rarest, highest-value biomes.
LOCKED_PING_BIOMES = {"glitched", "cyberspace", "dreamspace", "singularity"}

# Biomes rare enough to get the ✦ sigil, "RARE" tag, and Rarity field in
# the webhook embed. Singularity is included even though its ping mode
# isn't locked (the user can still set it to Message/Nothing).
RARE_TIER_BIOMES = LOCKED_PING_BIOMES | {"singularity"}

DEFAULT_BIOME_MODES = {
    "windy": "message", "snowy": "message", "rainy": "message",
    "sandstorm": "message", "hell": "message", "starfall": "message",
    "heaven": "ping", "corruption": "message", "null": "message",
    "glitched": "ping", "dreamspace": "ping", "cyberspace": "ping",
    "singularity": "ping",
}

# Icon filenames (in ui/biome_icons/) confirmed and assigned by the
# person maintaining this project. Windy reuses the Normal icon
# (no distinct art for it). All 14 tracked biomes now have an icon.
DEFAULT_BIOME_ICONS = {
    "normal": "normal.png", "windy": "normal.png", "snowy": "snowy.png", "rainy": "rainy.png",
    "sandstorm": "sandstorm.png", "hell": "hell.png", "corruption": "corruption.png",
    "heaven": "heaven.png", "starfall": "starfall.png", "null": "null.png",
    "dreamspace": "dreamspace.png", "cyberspace": "cyberspace.png", "glitched": "glitched.png",
    "singularity": "singularity.png",
}


OCR_RPC_GRACE = 6.0  # seconds OCR stays quiet after a Rich Presence change (HUD lags behind)
OCR_DEFAULTS = {"enabled": "true", "auto": "true", "calibrated": "false", "left": "0.0", "top": "0.8193",
                "width": "0.1687", "height": "0.05", "tick": "0.3", "ref_w": "0", "ref_h": "0", "validated": "false"}
OCR_SCAN_EVERY = 8.0   # seconds between whole-screen searches while the zone is not locked
OCR_FAILSAFE_FACTOR = 1.25   # an OCR-only biome that is no longer read is closed only once it is
OCR_FAILSAFE_PAD = 30.0      # LONGER than the biome can possibly last (real duration x1.25 + 30 s)
OCR_FAILSAFE_UNKNOWN = 1800.0  # ...or 30 min for a biome whose duration is not known
OCR_RESIZE_TOL = 0.02        # window size change (fullscreen <-> windowed) that triggers a new zone search
OCR_MISMATCH_S = 15.0       # OCR keeps reading something the log contradicts for this long -> the zone is wrong
OCR_DISTRUST_S = 3600.0     # a biome OCR announced and the log then denied is ignored from OCR for this long
LOG_VERIFY_EVERY = 2.0       # seconds between independent checks of the log's last biome
OCR_NEED_EXACT = 2      # identical reads in a row needed for an exact word match
OCR_NEED_FUZZY = 4      # ...and for a fuzzy one (misread letters)
LOG_CHECK_EVERY = 1.0  # seconds between 'is Roblox running / which log file' checks (they are slow)
SENT_GUARD_S = 3.0      # the same biome message is never sent twice within this window
OWN_TITLE = f"Radiance Macro v{APP_VERSION}"  # window title (app.py), to never read our own UI


def _data_dir():
    """Per-user writable folder (config, stats, journal). Next to the EXE is
    not safe: Program Files / System32 are read-only for normal users."""
    if os.name == "nt":
        d = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "Radiance Macro")
    else:
        d = os.path.join(os.path.expanduser("~"), ".radiance-macro")
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        d = os.path.dirname(os.path.abspath(sys.argv[0] or __file__))
    return d


DATA_DIR = _data_dir()
CONFIG_PATH = os.path.join(DATA_DIR, "config.ini")


def migrate_legacy_files():
    """v0.3 and older kept config.ini / radiance_data.json next to the app.
    Copy (never move) them into DATA_DIR once so nothing is lost."""
    here = {os.getcwd(), os.path.dirname(os.path.abspath(sys.argv[0] or __file__)),
            os.path.dirname(os.path.abspath(__file__))}
    for name in ("config.ini", "radiance_data.json", "radiance_data_session.json"):
        dst = os.path.join(DATA_DIR, name)
        if os.path.exists(dst):
            continue
        for d in here:
            src = os.path.join(d, name)
            if os.path.isfile(src) and os.path.abspath(src) != os.path.abspath(dst):
                try:
                    shutil.copy2(src, dst)
                except OSError:
                    pass
                break


def biome_key(event_name: str) -> str:
    return event_name.replace(" ", "_").lower()


def parse_ids(text):
    """'123, 456 789' -> ['123', '456', '789'] (digits only, junk ignored)."""
    return [t for t in (text or "").replace(",", " ").replace(";", " ").split() if t.isdigit()]


def fmt_duration(seconds):
    seconds = int(max(0, seconds))
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h}h {m:02d}m"
    if m:
        return f"{m}m {s:02d}s"
    return f"{s}s"


class PersistentStore:
    """Tiny JSON file next to config.ini that survives relaunches:
    all-time biome counts and a log of mid-biome Roblox drops."""

    def __init__(self, path):
        self.path = path
        self.data = {"lifetime": {}, "crashes": [], "sessions": [], "last_seen": {}}
        self.prev_seen = {}  # last_seen as it was BEFORE the current detection
        self.journal_path = os.path.splitext(path)[0] + "_session.json"
        self._lock = threading.Lock()
        try:
            with open(path, encoding="utf-8") as f:
                loaded = json.load(f)
            if isinstance(loaded, dict):
                for k in ("lifetime", "crashes", "sessions", "last_seen"):
                    if k in loaded:
                        self.data[k] = loaded[k]
        except (OSError, ValueError):
            pass

    def _save(self):
        try:
            tmp = self.path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.data, f)
            os.replace(tmp, self.path)
        except OSError:
            pass

    def add_biome(self, name):
        with self._lock:
            self.data["lifetime"][name] = self.data["lifetime"].get(name, 0) + 1
            self.prev_seen[name] = self.data["last_seen"].get(name)
            self.data["last_seen"][name] = time.time()
            self._save()

    def add_crash(self, biome):
        with self._lock:
            self.data["crashes"].append({"ts": time.time(), "biome": biome or ""})
            self.data["crashes"] = self.data["crashes"][-200:]
            self._save()

    def add_session(self, start, end, counts, recovered=False):
        with self._lock:
            self.data["sessions"].append({"start": start, "end": end,
                                          "counts": counts, "recovered": recovered})
            self.data["sessions"] = self.data["sessions"][-100:]
            self._save()

    # Crash-safe journal: rewritten on every biome event so an unexpected
    # close (crash, power loss) can still be summarized on the next launch.
    def write_journal(self, stats):
        try:
            with open(self.journal_path, "w", encoding="utf-8") as f:
                json.dump({"start": stats.session_start, "counts": stats.counts,
                           "updated": time.time()}, f)
        except OSError:
            pass

    def read_journal(self):
        try:
            with open(self.journal_path, encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            return None

    def clear_journal(self):
        try:
            os.remove(self.journal_path)
        except OSError:
            pass

    def crashes_since(self, days=7):
        cutoff = time.time() - days * 86400
        return sum(1 for c in self.data["crashes"] if c.get("ts", 0) >= cutoff)

    def lifetime_rare(self):
        return sum(n for name, n in self.data["lifetime"].items()
                   if biome_key(name) in RARE_TIER_BIOMES)


class SessionStats:
    """Tracks biome occurrences and durations for the current session,
    used for the in-app rarity/luck dashboard and the end-of-session
    Discord summary."""

    def __init__(self):
        self.store = None  # PersistentStore, set by the engine
        self.last_duration = {}  # biome -> seconds of its most recent run
        self.reset()

    def reset(self):
        self.session_start = None
        self.counts = {}          # biome name -> occurrence count
        self.total_seconds = {}   # biome name -> cumulative seconds active
        self._active_since = {}   # biome name -> timestamp when it started
        self.history = []         # ordered list of {event, action, ts}

    def start_session(self):
        self.reset()
        self.session_start = time.time()
        if self.store:
            self.store.write_journal(self)

    def record(self, event_name, action):
        now = time.time()
        self.history.append({"event": event_name, "action": action, "ts": now})
        if action == "started":
            self.counts[event_name] = self.counts.get(event_name, 0) + 1
            self._active_since[event_name] = now
            if self.store:
                self.store.add_biome(event_name)
                self.store.write_journal(self)
        elif action == "ended":
            started = self._active_since.pop(event_name, None)
            if started:
                self.total_seconds[event_name] = self.total_seconds.get(event_name, 0) + (now - started)
                self.last_duration[event_name] = now - started
            if self.store:
                self.store.write_journal(self)

    def elapsed_seconds(self):
        if not self.session_start:
            return 0
        return time.time() - self.session_start

    def rarest_seen(self, top_n=3):
        """Returns biome names sorted by rarity tier (rare/locked biomes
        first) then by lowest occurrence count - what the player most
        wants surfaced at a glance."""
        rare_order = ["SINGULARITY", "CYBERSPACE", "GLITCHED", "DREAMSPACE"]
        seen = list(self.counts.keys())
        seen.sort(key=lambda b: (rare_order.index(b) if b in rare_order else 99, self.counts[b]))
        return seen[:top_n]

    def as_dict(self):
        return {
            "elapsed_seconds": self.elapsed_seconds(),
            "counts": self.counts,
            "total_seconds": self.total_seconds,
            "history": self.history[-50:],  # cap for UI payload size
            "lifetime_rare": self.store.lifetime_rare() if self.store else 0,
            "crashes_7d": self.store.crashes_since(7) if self.store else 0,
        }

    def summary_lines(self):
        """Human-readable lines for the Discord session summary embed,
        rarest/most notable biomes first."""
        if not self.counts:
            return ["No biomes were detected this session."]
        rare_tier = {"SINGULARITY", "CYBERSPACE", "GLITCHED", "DREAMSPACE"}
        ordered = sorted(
            self.counts.items(),
            key=lambda kv: (kv[0] not in rare_tier, -kv[1]),
        )
        lines = []
        for name, count in ordered:
            marker = "✦" if name in rare_tier else "·"
            lines.append(f"{marker} **{name.title()}** — {count}x")
        return lines

    def to_csv_rows(self):
        """Full session history as CSV-ready rows (header + data), using
        self.history directly rather than as_dict()'s UI-capped copy so
        an export always has everything from the session, not just the
        last 50 events."""
        rows = [["timestamp", "date_time", "biome", "action"]]
        for entry in self.history:
            ts = entry["ts"]
            dt = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts))
            rows.append([f"{ts:.3f}", dt, entry["event"], entry["action"]])
        return rows


class Config:
    """Thin wrapper around configparser, same on-disk shape as before
    (webhook url, private server link, discord user id, per-biome modes)
    so existing setups aren't broken by the rewrite."""

    def __init__(self, path=CONFIG_PATH):
        self.path = path
        self.cp = configparser.ConfigParser()
        if not os.path.exists(path):
            self._write_defaults()
        self.cp.read(path, encoding='utf-8')
        # A zone saved by an older version was never checked against the log (it may be sitting on
        # some other text): search it again once, this time validated by the log.
        zone_outdated = self.cp.has_section('OCR') and not self.cp.has_option('OCR', 'validated')
        self._ensure_sections()
        if zone_outdated:
            self.cp.set('OCR', 'calibrated', 'false')
            self.save()
        self._migrate_legacy_mentions()
        self._migrate_legacy_webhook()

    def _write_defaults(self):
        cp = configparser.ConfigParser()
        cp['Webhook'] = {
            'webhooks_json': '[]', 'private_server': '', 'discord_user_id': '', 'discord_role_ids': '',
        }
        cp['Macro'] = {
            'roblox_username': '', 'min_rarity_to_ping': '', 'local_notifications': 'false',
        }
        cp['Biomes'] = dict(DEFAULT_BIOME_MODES)
        cp['BiomeIcons'] = dict(DEFAULT_BIOME_ICONS)
        with open(self.path, 'w', encoding='utf-8') as f:
            cp.write(f)

    def _ensure_sections(self):
        changed = False
        for section, defaults in (
            ('Webhook', {'webhooks_json': '[]', 'private_server': '', 'discord_user_id': '', 'discord_role_ids': ''}),
            ('Macro', {'roblox_username': '', 'min_rarity_to_ping': '', 'local_notifications': 'false'}),
            ('Biomes', DEFAULT_BIOME_MODES),
            ('BiomeIcons', DEFAULT_BIOME_ICONS),
            ('Mentions', {'users_json': '[]', 'roles_json': '[]', 'per_biome_json': '{}'}),
            ('OCR', OCR_DEFAULTS),
        ):
            if not self.cp.has_section(section):
                self.cp.add_section(section)
                changed = True
            for k, v in defaults.items():
                if not self.cp.has_option(section, k):
                    self.cp.set(section, k, str(v))
                    changed = True
        if changed:
            self.save()

    def _migrate_legacy_webhook(self):
        """Older configs stored a single webhook_url. Fold it into the
        new multi-webhook list once, then drop the legacy key."""
        if self.cp.has_option('Webhook', 'webhook_url'):
            legacy_url = self.cp.get('Webhook', 'webhook_url', fallback='').strip()
            if legacy_url:
                webhooks = self.get_webhooks()
                if not any(w['url'] == legacy_url for w in webhooks):
                    webhooks.append({"name": "Webhook 1", "url": legacy_url, "enabled": True})
                    self.set_webhooks(webhooks)
            self.cp.remove_option('Webhook', 'webhook_url')
            self.save()

    def save(self):
        with open(self.path, 'w', encoding='utf-8') as f:
            self.cp.write(f)

    def get(self, section, key, fallback=''):
        return self.cp.get(section, key, fallback=fallback)

    def set(self, section, key, value):
        self.cp.set(section, key, str(value))
        self.save()

    # ---- multi-webhook helpers ------------------------------------------

    def get_webhooks(self):
        """Returns a list of {name, url, enabled} dicts."""
        raw = self.get('Webhook', 'webhooks_json', fallback='[]')
        try:
            data = json.loads(raw)
            if isinstance(data, list):
                return data
        except (json.JSONDecodeError, TypeError):
            pass
        return []

    def set_webhooks(self, webhooks: list):
        self.cp.set('Webhook', 'webhooks_json', json.dumps(webhooks))
        self.save()

    def active_webhook_urls(self):
        return [w['url'] for w in self.get_webhooks() if w.get('enabled', True) and w.get('url')]

    # ---- biome icon assignment ------------------------------------------

    def get_biome_icons(self):
        """Maps biome_key -> icon filename (relative to ui/biome_icons/)."""
        if not self.cp.has_section('BiomeIcons'):
            return {}
        return dict(self.cp.items('BiomeIcons'))

    def set_biome_icon(self, key, filename):
        if not self.cp.has_section('BiomeIcons'):
            self.cp.add_section('BiomeIcons')
        if filename:
            self.cp.set('BiomeIcons', key, filename)
        elif self.cp.has_option('BiomeIcons', key):
            self.cp.remove_option('BiomeIcons', key)
        self.save()

    # ---- fake/test biome ping password -----------------------------------

    # ---- mentions: global users/roles + optional per-biome overrides -----

    def _mention_json(self, key, default):
        try:
            v = json.loads(self.get('Mentions', key, fallback='') or '')
            return v if isinstance(v, type(default)) else default
        except ValueError:
            return default

    @staticmethod
    def _norm_entries(entries):
        out, seen = [], set()
        for e in entries or []:
            if not isinstance(e, dict):
                continue
            i = str(e.get('id', '')).strip()
            if not i.isdigit() or i in seen:
                continue
            seen.add(i)
            out.append({'id': i, 'label': str(e.get('label') or '').strip()[:40] or i})
        return out[:25]

    @staticmethod
    def _norm_per_biome(raw):
        out = {}
        for key, v in (raw or {}).items():
            if key in DEFAULT_BIOME_MODES and isinstance(v, dict):
                out[key] = {
                    'users': [i for i in map(str, v.get('users', [])) if i.isdigit()],
                    'roles': [i for i in map(str, v.get('roles', [])) if i.isdigit()],
                }
        return out

    def get_mention_users(self):
        return self._norm_entries(self._mention_json('users_json', []))

    def get_mention_roles(self):
        return self._norm_entries(self._mention_json('roles_json', []))

    def get_mention_per_biome(self):
        return self._norm_per_biome(self._mention_json('per_biome_json', {}))

    def _store_mentions(self, key, value):
        if not self.cp.has_section('Mentions'):
            self.cp.add_section('Mentions')
        self.cp.set('Mentions', key, json.dumps(value))
        self.save()

    def set_mention_users(self, entries):
        norm = self._norm_entries(entries); self._store_mentions('users_json', norm); self._prune_per_biome(); return norm

    def set_mention_roles(self, entries):
        norm = self._norm_entries(entries); self._store_mentions('roles_json', norm); self._prune_per_biome(); return norm

    def set_mention_per_biome(self, mapping):
        norm = self._norm_per_biome(mapping); self._store_mentions('per_biome_json', norm); return norm

    def _prune_per_biome(self):
        """Drop per-biome mention IDs that no longer exist in the global lists
        (otherwise a removed user would still be pinged for that biome)."""
        users = {u['id'] for u in self.get_mention_users()}
        roles = {r['id'] for r in self.get_mention_roles()}
        cur = self.get_mention_per_biome()
        new = {k: {'users': [i for i in v['users'] if i in users],
                   'roles': [i for i in v['roles'] if i in roles]} for k, v in cur.items()}
        if new != cur:
            self._store_mentions('per_biome_json', new)

    # ---- OCR settings (fractions of the Roblox window) ------------------

    def get_ocr(self):
        def num(key, lo, hi):
            try:
                v = float(self.get('OCR', key, fallback=OCR_DEFAULTS[key]))
            except ValueError:
                v = float(OCR_DEFAULTS[key])
            return min(max(v, lo), max(lo, hi))
        left, top = num('left', 0.0, 0.95), num('top', 0.0, 0.95)
        return {"enabled": self.get('OCR', 'enabled', fallback='true') == 'true',
                "auto": self.get('OCR', 'auto', fallback='true') == 'true',
                "calibrated": self.get('OCR', 'calibrated', fallback='false') == 'true',
                "validated": self.get('OCR', 'validated', fallback='false') == 'true',
                "left": left, "top": top,
                "width": num('width', 0.02, 1 - left), "height": num('height', 0.02, 1 - top),
                "interval": num('tick', 0.15, 5.0),
                "ref_w": self._int('OCR', 'ref_w'), "ref_h": self._int('OCR', 'ref_h')}

    def _int(self, section, key):
        try:
            return max(0, int(float(self.get(section, key, fallback='0'))))
        except (TypeError, ValueError):
            return 0

    def set_ocr(self, d):
        if not self.cp.has_section('OCR'):
            self.cp.add_section('OCR')
        for k in ('ref_w', 'ref_h'):
            if k in d:
                try:
                    self.cp.set('OCR', k, str(max(0, int(d[k]))))
                except (TypeError, ValueError):
                    pass
        for flag in ('enabled', 'auto', 'calibrated', 'validated'):
            if flag in d:
                self.cp.set('OCR', flag, 'true' if d[flag] else 'false')
        for k in ('left', 'top', 'width', 'height', 'interval'):
            if k in d:
                try:
                    self.cp.set('OCR', 'tick' if k == 'interval' else k, str(float(d[k])))
                except (TypeError, ValueError):
                    pass
        self.save()
        return self.get_ocr()

    def _migrate_legacy_mentions(self):
        """Older configs kept one user ID (and, in v0.2, role IDs) under
        [Webhook]. Move them into the Mentions lists once, then clear them."""
        old_users = parse_ids(self.cp.get('Webhook', 'discord_user_id', fallback=''))
        old_roles = parse_ids(self.cp.get('Webhook', 'discord_role_ids', fallback=''))
        if not (old_users or old_roles):
            return
        users, roles = self.get_mention_users(), self.get_mention_roles()
        for n, uid in enumerate(old_users):
            users.append({'id': uid, 'label': 'Me' if n == 0 and not users else f'User {uid[-4:]}'})
        for rid in old_roles:
            roles.append({'id': rid, 'label': f'Role {rid[-4:]}'})
        self.cp.set('Webhook', 'discord_user_id', '')
        self.cp.set('Webhook', 'discord_role_ids', '')
        self.set_mention_users(users)
        self.set_mention_roles(roles)

    def as_dict(self):
        d = {s: dict(self.cp.items(s)) for s in self.cp.sections()}
        d['Webhook']['webhooks'] = self.get_webhooks()
        return d


def detect_roblox_version():
    """Returns 'player', 'store', or None. Mirrors maxstellar's process scan."""
    for proc in psutil.process_iter(['name']):
        try:
            name = proc.info['name'] or ''
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
        if 'RobloxPlayerBeta.exe' in name:
            return 'player'
        if 'Windows10Universal.exe' in name:
            return 'store'
    return None


def get_log_dir(version: str):
    if version == 'player':
        return LOG_DIR
    if version == 'store':
        if not os.path.isdir(PACKAGES_PATH):
            return None
        for folder in os.listdir(PACKAGES_PATH):
            if folder.startswith("ROBLOXCORPORATION.ROBLOX"):
                return os.path.join(PACKAGES_PATH, folder, "LocalState", "logs")
    return None


def get_latest_log_file(log_dir: str, current: str = None):
    """The Roblox player log that is really being written.
    Newest *write* wins (creation time alone can point at a finished session), Studio and
    installer logs are ignored, and the file we already follow is kept while it is still
    being written unless a newer log has been created (a new Roblox session)."""
    if not log_dir or not os.path.isdir(log_dir):
        return None
    cands = []
    try:
        with os.scandir(log_dir) as it:
            for e in it:
                if not e.name.endswith(".log") or "Installer" in e.name or "Studio" in e.name:
                    continue
                try:
                    st = e.stat()
                except OSError:
                    continue
                cands.append((e.path, st.st_mtime, st.st_ctime))
    except OSError:
        return None
    if not cands:
        return None
    best = max(cands, key=lambda c: c[1])
    if current:
        cur = next((c for c in cands if os.path.normcase(c[0]) == os.path.normcase(current)), None)
        if cur and time.time() - cur[1] < 20 and best[2] <= cur[2] + 1:
            return cur[0]
    return best[0]


class LogTail:
    """Reads everything new in a growing log file in big chunks and returns only
    the complete Rich Presence lines. The old loop read ONE line per turn and
    re-scanned every process and every log file on each turn, so it fell behind
    as soon as Roblox wrote a lot - and never caught up."""

    MARK = b'"hoverText"'   # only Rich Presence lines carry it: cheap pre-filter
    CHUNK = 8 * 1024 * 1024

    def __init__(self, path):
        self.path = path
        self.f = open(path, "rb")
        self.f.seek(0, os.SEEK_END)      # only what is written from now on
        self.buf = b""
        self.last_growth = time.time()   # last time Roblox wrote anything

    def read_new(self):
        data = self.f.read(self.CHUNK)
        if not data:
            try:  # file truncated or rewritten in place: our position is now past its end
                if os.fstat(self.f.fileno()).st_size < self.f.tell():
                    self.f.seek(0)
                    self.buf = b""
            except OSError:
                pass
            return []
        self.last_growth = time.time()
        data = self.buf + data
        parts = data.split(b"\n")
        self.buf = parts.pop()           # incomplete last line: wait for the rest
        if len(self.buf) > 4 * 1024 * 1024:
            self.buf = b""               # garbage without a newline: do not grow forever
        return [p for p in parts if self.MARK in p]

    def close(self):
        try:
            self.f.close()
        except OSError:
            pass


class WebhookSender:
    """Background FIFO sender. Discord I/O never blocks the detection loop,
    failed sends are retried, and every URL keeps its last result (used by
    the Diagnostic panel). Order is preserved (Started always before Ended)."""

    RETRY_DELAYS = (2, 5, 15)   # seconds between attempts
    PERMANENT = (400, 401, 403, 404)  # retrying cannot fix these

    def __init__(self, on_log):
        self.on_log = on_log
        self.status = {}  # url -> {"ok", "code", "error", "ts"}
        self._q = queue.Queue()
        self._pending = 0
        self._lock = threading.Lock()
        self._idle = threading.Event()
        self._idle.set()
        threading.Thread(target=self._worker, daemon=True).start()

    def submit(self, wh, url, label):
        with self._lock:
            self._pending += 1
            self._idle.clear()
        self._q.put((wh, url, label))

    def pending(self):
        return self._pending

    def flush(self, timeout=8.0):
        """Wait until everything queued so far has been delivered (or given up)."""
        return self._idle.wait(timeout)

    def _set(self, url, ok, code, error):
        self.status[url] = {"ok": ok, "code": code, "error": error, "ts": time.time()}

    def _worker(self):
        while True:
            wh, url, label = self._q.get()
            try:
                self._deliver(wh, url, label)
            except Exception as e:  # never let the worker die
                self.on_log(f"Webhook error ({label}): {e}")
            finally:
                with self._lock:
                    self._pending = max(0, self._pending - 1)
                    if self._pending == 0:
                        self._idle.set()

    def _deliver(self, wh, url, label):
        err, code = "", None
        for attempt in range(len(self.RETRY_DELAYS) + 1):
            try:
                resp = wh.execute()
                if isinstance(resp, list):
                    resp = resp[-1] if resp else None
                code = getattr(resp, "status_code", None)
                if code is None or code < 400:
                    self._set(url, True, code, "")
                    return
                err = f"HTTP {code}"
                if code in self.PERMANENT:
                    self._set(url, False, code, err)
                    self.on_log(f"Webhook '{label}' rejected by Discord ({err}) - check the URL. Not retried.")
                    return
            except Exception as e:
                err = f"{type(e).__name__}: {e}"
            if attempt < len(self.RETRY_DELAYS):
                time.sleep(self.RETRY_DELAYS[attempt])
        self._set(url, False, code, err)
        self.on_log(f"Webhook '{label}' failed after {len(self.RETRY_DELAYS) + 1} attempts ({err}).")


class DetectionEngine:
    """
    Runs in a background thread. Emits events to a UI callback:
      on_status(status: str)
      on_biome(event: str, action: 'started'|'ended')
      on_log(message: str)
    """

    def __init__(self, config: Config, on_status=None, on_biome=None, on_log=None, on_stats=None):
        self.config = config
        self.on_status = on_status or (lambda s: None)
        self.on_biome = on_biome or (lambda e, a: None)
        self.on_log = on_log or (lambda m: None)
        self.on_stats = on_stats or (lambda s: None)
        self.stats = SessionStats()
        self._current_biome = None  # biome running right now (None = Normal / unknown)
        self.store = PersistentStore(os.path.join(
            os.path.dirname(os.path.abspath(config.path)), "radiance_data.json"))
        self.stats.store = self.store

        self.sender = WebhookSender(lambda m: self.on_log(m))
        self._last_event = None       # biome currently believed active ("NORMAL" counts)
        self._event_lock = threading.RLock()
        self._last_rpc_ts = 0.0
        self._last_source = None      # 'rpc' or 'ocr': who started the current biome
        self._last_change_ts = 0.0
        self.source_stats = {"rpc": {"first": 0, "lead_s": 0.0}, "ocr": {"first": 0, "lead_s": 0.0}}
        self._confirmed = False       # the other source already confirmed the current biome
        self._sent_guard = {}         # (biome, action) -> time of last send
        self._rpc_lag = None          # seconds between Roblox writing a log line and us reading it
        self._ocr_msg = ""
        self._last_rpc = None         # (event, timestamp) of the last Rich Presence line
        self._roblox_version = None
        self._log_path = None
        self._tail = None             # LogTail of the log being followed
        self._log_check = None        # last independent check of the log: {'event', 'ts'}
        self._ocr_distrust = {}       # biome -> time until which OCR may not announce it
        self._ocr_unvalidate = False  # set when the log contradicted an OCR-started biome
        self._verify_pending = None
        self.ocr_info = {"text": "", "match": None, "score": 0.0, "ts": 0, "error": ""}
        self._gen = 0                 # bumps on every start(); stale threads exit

        self._running = False
        self._paused = False
        self._stop_flag = threading.Event()
        self._thread = None
        self._ocr_thread = None

    # ---- lifecycle -----------------------------------------------------

    def start(self):
        if self._running:
            return
        self._stop_flag.clear()
        self._gen += 1
        self._running = True
        self._paused = False
        self._last_event = None
        self._last_source = None
        self._last_change_ts = 0.0
        self._confirmed = False
        self._ocr_msg = ""
        self._current_biome = None
        self.stats.start_session()
        self._send_lifecycle_webhook("started")
        self._thread = threading.Thread(target=self._run, args=(self._gen,), daemon=True)
        self._thread.start()
        self._ocr_thread = threading.Thread(target=self._ocr_loop, args=(self._gen,), daemon=True)
        self._ocr_thread.start()

    def pause(self):
        if not self._running:
            return
        self._paused = not self._paused
        self._send_lifecycle_webhook("paused" if self._paused else "resumed")
        self.on_status("paused" if self._paused else "running")

    def _finish_session(self):
        """Archive the finished session for the multi-session history."""
        st = self.stats
        if st.session_start and time.time() - st.session_start >= 60:
            self.store.add_session(st.session_start, time.time(), dict(st.counts))
        self.store.clear_journal()

    def recover_unsent_session(self):
        """If the last run ended without Stop (crash, power loss), send its
        summary now from the saved journal. Duration runs up to the last
        biome event that was saved."""
        j = self.store.read_journal()
        if not j:
            return
        self.store.clear_journal()
        start, counts = j.get("start"), j.get("counts") or {}
        if not start or not counts:
            return
        end = j.get("updated") or start
        self.store.add_session(start, end, counts, recovered=True)
        tmp = SessionStats()
        tmp.counts = counts
        self._send_session_summary(stats=tmp, duration_override=end - start, recovered=True)
        self.on_log("Sent the summary of a session that ended unexpectedly.")

    def stop(self):
        if self._running:
            self._send_lifecycle_webhook("stopped")
            if self._current_biome:  # close the running biome so its time is counted
                self.stats.record(self._current_biome, "ended")
                self._current_biome = None
            self._send_session_summary()
            self._finish_session()
        self._running = False
        self._stop_flag.set()
        self._last_event = None
        self.sender.flush(8.0)  # let the final messages leave before the app can exit
        self.on_status("stopped")

    # ---- webhook helpers -------------------------------------------------

    def _active_urls(self):
        return [u for u in self.config.active_webhook_urls() if "discord" in u and u.startswith("https://")]

    def _new_wh(self, url, **kw):
        # timeout: never hang on a dead connection; rate_limit_retry: honour Discord 429s
        return DiscordWebhook(url=url, timeout=10, rate_limit_retry=True, **kw)

    def _submit(self, wh, url, label):
        self.sender.submit(wh, url, label)

    def _icon(self):
        """Returns FOOTER_ICON if it's set, else None - passing an empty
        string to Discord's icon_url fields causes silently dropped or
        malformed embeds, so callers should treat None as 'omit it'."""
        return FOOTER_ICON or None

    def _send_lifecycle_webhook(self, state):
        urls = self._active_urls()
        if not urls:
            return
        icon = self._icon()

        # Each lifecycle state gets its own sigil, accent color, and short
        # line - same visual language as the biome embeds, just for the
        # macro's own status rather than a detected biome.
        states = {
            "started": {
                "sigil": "▶", "title": "Macro Started",
                "line": "Watching for biome changes.",
                "color": 0x4ADE80,  # green
            },
            "paused": {
                "sigil": "⏸", "title": "Macro Paused",
                "line": "Detection is on hold.",
                "color": 0xD4AF37,  # gold
            },
            "resumed": {
                "sigil": "▶", "title": "Macro Resumed",
                "line": "Back to watching for biome changes.",
                "color": 0x4ADE80,
            },
            "stopped": {
                "sigil": "■", "title": "Macro Stopped",
                "line": "Detection has ended for this session.",
                "color": 0xB5544A,  # muted red
            },
        }
        info = states.get(state, {
            "sigil": "✦", "title": "Radiance Macro", "line": state, "color": DEFAULT_ACCENT,
        })

        for url in urls:
            try:
                wh = self._new_wh(url)
                embed = DiscordEmbed(
                    title=f"{info['sigil']}  {info['title']}",
                    description=f"*{info['line']}*",
                    color=info["color"],
                )
                if icon:
                    embed.set_author(name="Radiance Macro", icon_url=icon)
                    embed.set_footer(text=f"{APP_NAME} · v{APP_VERSION}", icon_url=icon)
                else:
                    embed.set_author(name="Radiance Macro")
                    embed.set_footer(text=f"{APP_NAME} · v{APP_VERSION}")
                embed.set_timestamp()
                wh.add_embed(embed)
                self._submit(wh, url, "lifecycle")
            except Exception as e:
                self.on_log(f"Webhook error: {e}")

    def _biome_mode(self, event_name):
        key = biome_key(event_name)
        if key in LOCKED_PING_BIOMES:
            return 'ping'
        return self.config.get('Biomes', key, fallback='message')

    def _load_icon_attachment(self, event_name):
        icon_filename = self.config.get_biome_icons().get(biome_key(event_name), "")
        icon_path = os.path.join(BIOME_ICONS_DIR, icon_filename) if icon_filename else None
        if icon_path and os.path.isfile(icon_path):
            try:
                with open(icon_path, "rb") as f:
                    return icon_filename, f.read()
            except OSError as e:
                self.on_log(f"Could not read icon {icon_filename}: {e}")
        return None, None

    def _handle_roblox_disconnect(self, active_biome):
        """Fires when Roblox stops being detected while the engine was
        actively watching it - distinct from the normal 'waiting for
        Roblox to open' idle state. If a biome was active at the moment
        of disconnect, that's flagged clearly: a macro checker cares a
        lot about the difference between 'closed cleanly between biomes'
        and 'dropped mid-biome, possibly a crash'."""
        if active_biome:
            self.stats.record(active_biome, "ended")
            self.on_biome(active_biome, "ended")
            self.store.add_crash(active_biome)
            self.on_stats(self.stats.as_dict())
        self.on_log(
            f"Roblox closed or disconnected"
            + (f" while {active_biome.title()} was active." if active_biome else ".")
        )
        self._send_disconnect_webhook(active_biome)

    def _send_disconnect_webhook(self, active_biome):
        urls = self._active_urls()
        if not urls:
            return
        icon = self._icon()
        was_mid_biome = bool(active_biome)
        title = "⚠  Roblox Disconnected"
        if was_mid_biome:
            line = f"Connection was lost while **{active_biome.title()}** was active. Could be a crash — worth checking."
            color = 0xB5544A  # same muted red as Macro Stopped, signals "needs attention"
        else:
            line = "Roblox closed while the macro was idle between biomes."
            color = 0x6B6248  # gold-dim, lower-severity than a mid-biome drop
        for url in urls:
            try:
                wh = self._new_wh(url)
                embed = DiscordEmbed(title=title, description=f"*{line}*", color=color)
                if icon:
                    embed.set_author(name="Radiance Macro", icon_url=icon)
                    embed.set_footer(text=f"{APP_NAME} · v{APP_VERSION}", icon_url=icon)
                else:
                    embed.set_author(name="Radiance Macro")
                    embed.set_footer(text=f"{APP_NAME} · v{APP_VERSION}")
                embed.set_timestamp()
                wh.add_embed(embed)
                self._submit(wh, url, "disconnect")
            except Exception as e:
                self.on_log(f"Webhook error: {e}")

    def _maybe_notify_local(self, event_name):
        """Local sound + Windows toast for rare biomes, independent of
        Discord. Off by default-safe (checks the config toggle), and
        always fired on its own thread so a slow or broken notification
        call can never delay the next log read."""
        if notify is None:
            return
        if biome_key(event_name) not in RARE_TIER_BIOMES:
            return
        if self.config.get('Macro', 'local_notifications', fallback='false') != 'true':
            return
        threading.Thread(
            target=notify.notify_rare_biome, args=(event_name,), daemon=True
        ).start()

    def _mention_targets_for(self, event_name):
        """(user_ids, role_ids) to ping for this biome: its own override if the
        Mentions tab defines one, otherwise the global lists."""
        own = self.config.get_mention_per_biome().get(biome_key(event_name))
        if own is not None:
            return own['users'], own['roles']
        return ([u['id'] for u in self.config.get_mention_users()],
                [r['id'] for r in self.config.get_mention_roles()])

    def _send_biome_webhook(self, event_name, action, source="rpc"):
        mode = self._biome_mode(event_name)
        if mode == 'nothing':
            return
        now = time.time()
        if now - self._sent_guard.get((event_name, action), 0.0) < SENT_GUARD_S:
            return
        self._sent_guard[(event_name, action)] = now
        urls = self._active_urls()
        if not urls:
            self.on_log("No active webhook - biome event not sent.")
            return

        key = biome_key(event_name)
        is_rare = key in RARE_TIER_BIOMES
        started = action == "started"
        color = BIOME_COLORS.get(event_name, DEFAULT_ACCENT)
        flavor = BIOME_FLAVOR.get(event_name, "A shift moves through the world.")

        if started:
            title = f"{'✦' if is_rare else '✧'}  {event_name.title()}{'  ·  RARE' if is_rare else ''}"
        else:
            title = f"{event_name.title()} — Ended"

        # One compact status line instead of a column of small fields.
        count_so_far = self.stats.counts.get(event_name, 0)
        bits = []
        if started:
            bits.append("🟢 **Started**")
            if is_rare:
                prev = self.store.prev_seen.get(event_name)
                if prev:
                    bits.append(f"last seen {fmt_duration(time.time() - prev)} ago")
        else:
            bits.append("⚪ **Ended**")
            dur = self.stats.last_duration.get(event_name)
            if dur:
                bits.append(f"lasted `{fmt_duration(dur)}`")
        if count_so_far:
            bits.append(f"`{count_so_far}x` this session")
        description = f"*{flavor}*\n\n" + "  ·  ".join(bits)
        ps_url = self.config.get('Webhook', 'private_server')
        fields = []
        if started and ps_url:
            fields.append({"name": "Server", "value": f"[Join private server →]({ps_url})", "inline": False})

        player = self.config.get('Macro', 'roblox_username', fallback='').strip()
        author_name = f"{player}  ·  Radiance Macro" if player else "Radiance Macro"
        icon = self._icon()
        icon_filename, icon_bytes = self._load_icon_attachment(event_name)
        # The four rare biomes get a separate, real @everyone message after the
        # normal biome embed. Keep the embed itself free of mention content so
        # Discord delivers two distinct messages in the requested order.
        everyone_ping = started and key in LOCKED_PING_BIOMES
        if everyone_ping:
            ping_users, ping_roles = [], []
            content = None
            allowed = {"parse": []}
        else:
            ping_users, ping_roles = self._mention_targets_for(event_name) if (started and mode == 'ping') else ([], [])
            content = " ".join([f"<@{u}>" for u in ping_users] + [f"<@&{r}>" for r in ping_roles]) or None
            # Only the listed users/roles can be notified; nothing else in a message can ping.
            allowed = {"users": ping_users, "roles": ping_roles} if content else {"parse": []}

        for url in urls:
            try:
                wh = self._new_wh(url, allowed_mentions=allowed)
                embed = DiscordEmbed(title=title, description=description, color=color)
                if icon:
                    embed.set_author(name=author_name, icon_url=icon)
                    embed.set_footer(text=f"{APP_NAME} · v{APP_VERSION}", icon_url=icon)
                else:
                    embed.set_author(name=author_name)
                    embed.set_footer(text=f"{APP_NAME} · v{APP_VERSION}")
                for f in fields:
                    embed.add_embed_field(name=f["name"], value=f["value"], inline=f["inline"])
                if icon_bytes:
                    wh.add_file(file=icon_bytes, filename=icon_filename)
                    embed.set_thumbnail(url=f"attachment://{icon_filename}")
                    if is_rare and started:
                        embed.set_image(url=f"attachment://{icon_filename}")
                embed.set_timestamp()
                if content:
                    wh.set_content(content)
                wh.add_embed(embed)
                self._submit(wh, url, "biome")

                # Send a second standalone message so @everyone is a genuine
                # Discord mention, not just text embedded in the rich message.
                # Public release notifications only: no simulated test-ping path.
                if everyone_ping:
                    ping_wh = self._new_wh(url, allowed_mentions={"parse": ["everyone"]})
                    ping_wh.set_content("@everyone")
                    self._submit(ping_wh, url, "biome-everyone")
            except Exception as e:
                self.on_log(f"Webhook error: {e}")

    def _send_session_summary(self, stats=None, duration_override=None, recovered=False):
        urls = self._active_urls()
        if not urls:
            return
        stats = stats or self.stats
        elapsed = int(duration_override if duration_override is not None else stats.elapsed_seconds())
        player = self.config.get('Macro', 'roblox_username', fallback='').strip()
        counts = stats.counts
        rare = {n: c for n, c in counts.items() if biome_key(n) in RARE_TIER_BIOMES}
        other = {n: c for n, c in counts.items() if n not in rare}

        lines = []
        if recovered:
            lines += ["*Recovered after an unexpected close — last saved state.*", ""]
        if not counts:
            lines.append("*No biomes were detected this session.*")
        else:
            if rare:
                lines.append("**✦  Rare hits**")
                for n, c in sorted(rare.items(), key=lambda kv: -kv[1]):
                    lines.append(f"✦ **{n.title()}**  ×{c}")
            else:
                lines.append("*No rare biomes this session.*")
            if other:
                lines += ["", "**Everything else**",
                          "  ·  ".join(f"{n.title()} ×{c}" for n, c in sorted(other.items(), key=lambda kv: -kv[1]))]

        fields = [
            {"name": "Duration", "value": f"`{fmt_duration(elapsed)}`", "inline": True},
            {"name": "Detections", "value": f"`{sum(counts.values())}`", "inline": True},
        ]
        if stats.total_seconds:
            top, secs = max(stats.total_seconds.items(), key=lambda kv: kv[1])
            fields.append({"name": "Most time in", "value": f"{top.title()} · `{fmt_duration(secs)}`", "inline": True})
        if rare and elapsed >= 600:
            fields.append({"name": "Rare / hour", "value": f"`{sum(rare.values()) / (elapsed / 3600):.2f}`", "inline": True})

        color = DEFAULT_ACCENT
        for name in ("SINGULARITY", "CYBERSPACE", "GLITCHED", "DREAMSPACE"):
            if name in counts:
                color = BIOME_COLORS.get(name, DEFAULT_ACCENT)
                break
        title = "✦  Session Summary" + ("  ·  recovered" if recovered else "")
        author_name = f"{player}  ·  Radiance Macro" if player else "Radiance Macro"
        icon = self._icon()

        for url in urls:
            try:
                wh = self._new_wh(url)
                embed = DiscordEmbed(title=title, description="\n".join(lines), color=color)
                if icon:
                    embed.set_author(name=author_name, icon_url=icon)
                    embed.set_thumbnail(url=icon)
                    embed.set_footer(text=f"{APP_NAME} · v{APP_VERSION}", icon_url=icon)
                else:
                    embed.set_author(name=author_name)
                    embed.set_footer(text=f"{APP_NAME} · v{APP_VERSION}")
                for f in fields:
                    embed.add_embed_field(name=f["name"], value=f["value"], inline=f["inline"])
                embed.set_timestamp()
                wh.add_embed(embed)
                self._submit(wh, url, "summary")
            except Exception as e:
                self.on_log(f"Webhook error: {e}")

    # ---- biome state machine (shared by Rich Presence and OCR) -------------

    @staticmethod
    def _parse_rpc_line(line):
        """Biome name from a Roblox log line, or None."""
        return parse_rpc_line(line)

    @staticmethod
    def _line_lag(line):
        """Seconds between Roblox writing a log line and now (None if no timestamp).
        Log timestamps are UTC: '2026-10-05T03:18:06.512Z,...'"""
        import calendar
        try:
            t = calendar.timegm(time.strptime(line[:19], "%Y-%m-%dT%H:%M:%S"))
            frac = float(line[19:23]) if line[19:20] == "." else 0.0
            return time.time() - (t + frac)
        except (ValueError, IndexError):
            return None

    def _initial_event(self, path):
        """Last Rich Presence biome already written in this log (scanned backwards
        in 1 MB steps, up to 16 MB) so a macro started mid-biome does not miss it."""
        try:
            size = os.path.getsize(path)
            fh = open(path, "rb")
        except OSError:
            return None
        carry, pos = b"", size
        with fh:
            for _ in range(16):
                start = max(0, pos - (1 << 20))
                fh.seek(start)
                data = fh.read(pos - start) + carry
                lines = data.split(b"\n")
                carry = lines[0] if start > 0 else b""   # may be cut in half: finish it with the older chunk
                body = lines[1:] if start > 0 else lines
                for ln in reversed(body):
                    if LogTail.MARK in ln:
                        ev = self._parse_rpc_line(ln.decode("utf-8", errors="ignore"))
                        if ev:
                            return ev
                if start == 0:
                    break
                pos = start
        return None

    def _last_log_event(self, path, max_bytes=512 * 1024):
        """Newest biome written in the log, read through a FRESH file handle (independent of
        the live reader's position)."""
        try:
            size = os.path.getsize(path)
            with open(path, "rb") as fh:
                fh.seek(max(0, size - max_bytes))
                data = fh.read()
        except OSError:
            return None
        for ln in reversed(data.split(b"\n")):
            if LogTail.MARK in ln:
                ev = self._parse_rpc_line(ln.decode("utf-8", errors="ignore"))
                if ev:
                    return ev
        return None

    def _verify_log(self, path):
        """Safety net: every few seconds, compare the biome the log says with the last one the
        live reader saw. A difference that lasts for two checks means the live reader missed
        something (stale handle, file replaced...): catch up. Returns True when it did."""
        ev = self._last_log_event(path)
        self._log_check = {"event": ev, "ts": time.time()}
        last = self._last_rpc[0] if self._last_rpc else None
        if not ev or ev == last:
            self._verify_pending = None
            return False
        if self._verify_pending != ev:   # wait for a second look: never race the live reader
            self._verify_pending = ev
            return False
        self._verify_pending = None
        self._last_rpc = (ev, time.time())
        if self._paused:
            self._silent_sync(ev)
        else:
            self._apply_event(ev, "rpc")
        self.on_log(f"[LOG] check caught a change the live reader had missed: {ev.title()}")
        return True

    def _tail_events(self, path, n=6):
        """Last `n` biome lines of the Roblox log as (local HH:MM:SS, biome),
        newest first: the same feed the F9 developer console shows, read
        straight from the log file without opening anything in the game."""
        import datetime as _dt
        try:
            size = os.path.getsize(path)
            with open(path, "rb") as fh:
                fh.seek(max(0, size - 256 * 1024))
                tail = fh.read().decode("utf-8", errors="ignore")
        except OSError:
            return []
        out = []
        for line in reversed(tail.splitlines()):
            ev = self._parse_rpc_line(line)
            if not ev:
                continue
            stamp = ""
            try:  # log timestamps are UTC ("2026-10-05T03:18:06.5Z,...")
                t = _dt.datetime.strptime(line[:19], "%Y-%m-%dT%H:%M:%S").replace(tzinfo=_dt.timezone.utc)
                stamp = t.astimezone().strftime("%H:%M:%S")
            except ValueError:
                pass
            out.append({"time": stamp, "event": ev})
            if len(out) >= n:
                break
        return out

    def _apply_event(self, event, source="rpc"):
        """Single place where a biome change is processed. `source` is 'rpc'
        (Roblox log, authoritative) or 'ocr' (on-screen text)."""
        with self._event_lock:
            now = time.time()
            if event and event == self._last_event:
                # The other source agrees with what is already sent: no second message,
                # just keep score of who was first and by how much.
                if (source != self._last_source and not self._confirmed and self._last_change_ts
                        and now - self._last_change_ts < 30):
                    self._confirmed = True
                    lead = now - self._last_change_ts
                    st = self.source_stats.get(self._last_source)
                    if st is not None:
                        st["lead_s"] += lead
                    self.on_log(f"{event.title()}: {'log' if self._last_source == 'rpc' else 'OCR'} was first, "
                                f"{'OCR' if source == 'ocr' else 'log'} confirmed {lead:.1f}s later.")
                return False
            if not event:
                return False
            if source == "ocr" and now - self._last_rpc_ts < OCR_RPC_GRACE:
                return False  # the HUD may still show the previous biome
            if source == "rpc":
                self._last_rpc_ts = now
            prev = self._last_event
            if (source == "rpc" and self._last_source == "ocr" and prev not in (None, "NORMAL")
                    and event != prev and now - self._last_change_ts < 30):
                # OCR said `prev`, then the log said something else within seconds: OCR was wrong.
                self._ocr_distrust[prev] = now + OCR_DISTRUST_S
                self._ocr_unvalidate = True
                self.on_log(f"[OCR] said {prev.title()} but the log says {event.title()} - "
                            f"ignoring OCR for {prev.title()} for an hour.")
            # A biome ends when we return to NORMAL *or* another biome replaces it.
            if prev not in (None, "NORMAL"):
                self.on_biome(prev, "ended")
                self.stats.record(prev, "ended")
                self._send_biome_webhook(prev, "ended")
            if event != "NORMAL":
                self.on_biome(event, "started")
                self.stats.record(event, "started")
                self._send_biome_webhook(event, "started", source=source)
                self._maybe_notify_local(event)
            self.on_stats(self.stats.as_dict())
            self._last_event = event
            self._last_source = source
            self._last_change_ts = now
            self._confirmed = False
            if event != "NORMAL":
                self.source_stats[source]["first"] += 1
            self._current_biome = None if event == "NORMAL" else event
            if source == "ocr":
                self.on_log(f"[OCR] {event.title()} seen on screen.")
            return True

    def _silent_sync(self, event):
        """While paused: keep the state current without sending anything, so
        resuming does not produce false 'ended' / 'started' messages."""
        with self._event_lock:
            prev = self._last_event
            if prev == event:
                return
            if prev not in (None, "NORMAL"):
                self.stats.record(prev, "ended")  # close its timer, send nothing
            # A biome that starts while paused is never announced, so it is
            # treated as "nothing active": its later end must not be sent either.
            self._last_event = "NORMAL"
            self._current_biome = None

    # ---- OCR loop -----------------------------------------------------------

    def _ocr_say(self, msg):
        """Log an OCR status line once, not on every read."""
        if msg != self._ocr_msg:
            self._ocr_msg = msg
            self.on_log(f"[OCR] {msg}")

    def _ocr_auto_zone(self):
        """Look for the biome text on the whole game window and lock the zone."""
        expect = self._last_rpc[0] if self._last_rpc else None   # what the log says is active now
        res = ocr_mod.find_biome_text(list(BIOME_COLORS), avoid_title=OWN_TITLE, expect=expect)
        self.ocr_info = {"text": " · ".join(res.get("seen", [])[:6]), "match": res.get("match"),
                         "score": 1.0 if res.get("ok") else 0.0, "ts": time.time(),
                         "error": "" if res.get("ok") or "No biome name" in res.get("error", "") or "log says" in res.get("error", "") else res.get("error", "")}
        if res.get("ok") and res.get("region"):
            cw, ch = (res.get("client") or [0, 0])[:2]
            self.config.set_ocr(dict(res["region"], calibrated=True, ref_w=cw, ref_h=ch, validated=bool(res.get("validated"))))
            self._ocr_say(f"Biome text found ({res['match'].title()}) - zone locked automatically.")
            return True
        if self.ocr_info["error"] or "log says" in res.get("error", ""):
            self._ocr_say(self.ocr_info["error"] or res["error"])
        else:
            self._ocr_say("Looking for the biome text on screen...")
        return False

    def _ocr_failsafe_s(self, event):
        d = BIOME_DURATIONS.get(event)
        return d * OCR_FAILSAFE_FACTOR + OCR_FAILSAFE_PAD if d else OCR_FAILSAFE_UNKNOWN

    def _ocr_loop(self, gen):
        pending, hits, next_scan = None, 0, 0.0
        last_positive = 0.0           # last time OCR positively read the current biome
        size_seen, size_stable, rescan = None, 0, False
        mismatch_since = None         # since when OCR insists on something the log contradicts
        while not self._stop_flag.is_set() and gen == self._gen:
            cfg = self.config.get_ocr()
            if self._stop_flag.wait(cfg["interval"]):
                break
            if not cfg["enabled"] or self._paused or not self._roblox_version or ocr_mod is None:
                pending, hits, mismatch_since = None, 0, None
                continue
            if self._ocr_unvalidate:       # the log denied an OCR-started biome: the zone is suspect
                self._ocr_unvalidate = False
                self.config.set_ocr({"validated": False, "calibrated": False} if cfg["auto"] else {"validated": False})
                cfg = self.config.get_ocr()
            try:
                # Fullscreen <-> windowed (or any resize) moves the HUD: look for the text again.
                client_size = getattr(ocr_mod, "client_size", None)
                if cfg["auto"] and cfg["calibrated"] and cfg["ref_w"] and cfg["ref_h"] and client_size:
                    cs = client_size()
                    if cs:
                        changed = (abs(cs[0] - cfg["ref_w"]) / cfg["ref_w"] > OCR_RESIZE_TOL
                                   or abs(cs[1] - cfg["ref_h"]) / cfg["ref_h"] > OCR_RESIZE_TOL)
                        size_stable = size_stable + 1 if cs == size_seen else 0
                        size_seen = cs
                        if changed and size_stable >= 2 and not rescan:
                            rescan = True
                            self._ocr_say("Window size changed (windowed / fullscreen) - finding the biome text again.")
                        if not changed:
                            rescan = False
                if cfg["auto"] and (not cfg["calibrated"] or rescan):
                    if time.time() >= next_scan:
                        next_scan = time.time() + OCR_SCAN_EVERY
                        if self._ocr_auto_zone():
                            rescan = False
                    if not cfg["calibrated"]:
                        continue           # never calibrated: nothing to read yet
                res = ocr_mod.read_biome(cfg, list(BIOME_COLORS), avoid_title=OWN_TITLE)
            except Exception as e:
                res = {"text": "", "match": None, "score": 0.0, "error": f"{type(e).__name__}: {e}"}
            now = time.time()
            self.ocr_info = {"text": res.get("text", ""), "match": res.get("match"),
                             "score": res.get("score", 0.0), "ts": now, "error": res.get("error", ""),
                             "ms": res.get("ms", 0), "reused": res.get("reused", False),
                             "path": res.get("path", ""), "variant": res.get("variant", "")}
            if res.get("error"):
                # Roblox hidden / covered / minimized: we learn nothing, so nothing changes.
                self._ocr_say(res["error"])
                pending, hits = None, 0
                continue
            self._ocr_msg = ""
            name = res.get("match")
            log_cur = self._last_rpc[0] if self._last_rpc else None     # None = the log never spoke
            if name:
                if log_cur is not None and name == log_cur and not cfg["validated"]:
                    # OCR and the log read the same biome: this zone really is the biome text
                    self.config.set_ocr({"validated": True})
                    cfg["validated"] = True
                    self.on_log(f"[OCR] zone confirmed by the log ({name.title()}).")
                if name == self._last_event:
                    last_positive = now
                    mismatch_since = None
                    self._apply_event(name, "ocr")      # only confirms (score keeping)
                    pending, hits = None, 0
                    continue
                need = OCR_NEED_EXACT if res.get("score", 0) >= 0.999 else OCR_NEED_FUZZY
                hits = hits + 1 if name == pending else 1
                pending = name
                if hits >= need:
                    # While the log is speaking, OCR may not contradict it unless this zone has
                    # been proven right (it matched the log once) - a static wrong text can then
                    # never announce a biome. With a silent log, OCR works alone.
                    trusted = log_cur is None or cfg["validated"] or name == log_cur
                    if trusted and now >= self._ocr_distrust.get(name, 0.0):
                        if self._apply_event(name, "ocr"):
                            last_positive = now
                        mismatch_since = None
                    elif log_cur is not None:
                        mismatch_since = mismatch_since or now
                        if now - mismatch_since >= OCR_MISMATCH_S:
                            self._ocr_say(f"OCR keeps reading '{name.title()}' but the log says '{log_cur.title()}' "
                                          "- this zone is wrong, searching again.")
                            self.config.set_ocr({"validated": False, "calibrated": False} if cfg["auto"] else {"validated": False})
                            mismatch_since = None
                    pending, hits = None, 0
                continue
            # Nothing readable this time. That proves NOTHING: blur, glow or a particle over
            # the letters happen all the time, so it never ends a biome. An OCR-only biome ends
            # when OCR reads NORMAL / another biome, when the log says so, or - last resort -
            # once it has been unread for longer than that biome can possibly last.
            pending, hits = None, 0
            ev = self._last_event
            if (self._last_source == "ocr" and ev not in (None, "NORMAL")
                    and now - max(last_positive, self._last_change_ts) >= self._ocr_failsafe_s(ev)):
                self._apply_event("NORMAL", "ocr")

    # ---- diagnostics ----------------------------------------------------------

    @staticmethod
    def _screen_info():
        try:
            return ocr_mod.screen_info() if ocr_mod is not None else None
        except Exception:
            return None

    def log_biome(self):
        """Biome the Roblox log says is active (None while the log has said nothing)."""
        return self._last_rpc[0] if self._last_rpc else None

    def diagnostics(self):
        hooks = []
        for w in self.config.get_webhooks():
            st = self.sender.status.get(w.get("url"))
            hooks.append({"name": w.get("name") or "Webhook", "enabled": w.get("enabled", True),
                          "ok": None if not st else st["ok"],
                          "detail": "" if not st else (st["error"] or (f"HTTP {st['code']}" if st["code"] else "ok")),
                          "ts": st["ts"] if st else None})
        rpc = self._last_rpc
        roblox, log_path = self._roblox_version, self._log_path
        if not self._running:  # macro stopped: still look, so the panel is useful for setup
            try:
                roblox = detect_roblox_version()
                log_path = get_latest_log_file(get_log_dir(roblox), self._log_path) if roblox else None
            except Exception:
                roblox, log_path = None, None
        console = self._tail_events(log_path) if log_path else []
        return {
            "running": self._running, "paused": self._paused,
            "roblox": roblox,
            "log_path": os.path.basename(log_path) if log_path else None,
            "console": console,
            "last_rpc": {"event": rpc[0], "ts": rpc[1]} if rpc else None,
            "current": self._last_event,
            "queue": self.sender.pending(),
            "webhooks": hooks,
            "screen": self._screen_info(),
            "log_lag": self._rpc_lag,
            "log_check": ({"event": self._log_check["event"], "age": round(time.time() - self._log_check["ts"], 1)} if self._log_check else None),
            "log_idle_s": (round(time.time() - self._tail.last_growth, 1) if (self._tail and self._running) else None),
            "sources": {k: dict(v, lead_s=round(v["lead_s"], 1)) for k, v in self.source_stats.items()},
            "ocr": dict(self.ocr_info, enabled=self.config.get_ocr()["enabled"],
                        auto=self.config.get_ocr()["auto"], calibrated=self.config.get_ocr()["calibrated"],
                        validated=self.config.get_ocr()["validated"],
                        available=ocr_mod is not None),
        }

    # ---- main loop -------------------------------------------------------

    def _run(self, gen=None):
        gen = self._gen if gen is None else gen
        self.on_status("waiting_for_roblox")
        last_log_path = None
        roblox_was_running = False
        tail = None
        next_check = 0.0
        next_verify = 0.0

        while not self._stop_flag.is_set() and gen == self._gen:
            try:
                now = time.monotonic()
                if now >= next_check:
                    # Slow checks (all processes, all log files) at most once a second -
                    # never between two reads of the log.
                    next_check = now + LOG_CHECK_EVERY
                    version = detect_roblox_version()
                    self._roblox_version = version
                    if not version:
                        if roblox_was_running:
                            # Roblox was running and is gone: a close or a crash,
                            # not the normal "waiting to start" state.
                            with self._event_lock:
                                last = self._last_event
                                self._handle_roblox_disconnect(None if last in (None, "NORMAL") else last)
                                self._last_event = None
                                self._current_biome = None
                            roblox_was_running = False
                        if tail:
                            tail.close()
                            tail, self._tail, last_log_path = None, None, None
                        self.on_status("waiting_for_roblox")
                        time.sleep(0.3)
                        continue
                    roblox_was_running = True

                    latest_log = get_latest_log_file(get_log_dir(version), last_log_path)
                    if not latest_log:
                        self.on_status("waiting_for_roblox")
                        time.sleep(0.3)
                        continue
                    if latest_log != last_log_path:
                        if tail:
                            tail.close()
                        tail = LogTail(latest_log)
                        self._tail = tail
                        last_log_path = latest_log
                        self._log_path = latest_log
                        self.on_log(f"Using log file: {latest_log}")
                        self.on_status("running" if not self._paused else "paused")
                        initial = self._initial_event(latest_log)
                        if initial:
                            self._last_rpc = (initial, time.time())
                            if self._paused:
                                self._silent_sync(initial)
                            else:
                                self._apply_event(initial, "rpc")

                if tail is None:
                    time.sleep(0.2)
                    continue
                lines = tail.read_new()   # EVERYTHING new, not one line
                if not lines:
                    if time.monotonic() >= next_verify:
                        next_verify = time.monotonic() + LOG_VERIFY_EVERY
                        self._verify_log(tail.path)
                    time.sleep(0.03)
                    continue
                for raw in lines:         # in order: a burst may hold several changes
                    line = raw.decode("utf-8", errors="ignore")
                    event = self._parse_rpc_line(line)
                    if event is None:
                        continue
                    self._last_rpc = (event, time.time())
                    self._rpc_lag = self._line_lag(line)
                    if self._paused:
                        self._silent_sync(event)
                    else:
                        self._apply_event(event, "rpc")
            except Exception as e:  # one bad iteration must not kill detection
                self.on_log(f"Detection error: {type(e).__name__}: {e}")
                time.sleep(1.0)

        if tail:
            tail.close()
