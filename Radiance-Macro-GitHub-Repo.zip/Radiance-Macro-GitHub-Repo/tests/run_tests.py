"""Mock-based tests: no network, no Roblox, no Windows needed.  python tests/run_tests.py"""
import os, sys, json, time, tempfile, threading
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
import engine, ocr
REAL_LATEST = engine.get_latest_log_file      # tests below monkeypatch the module attribute

TMP = tempfile.mkdtemp()
sent = []          # (kind-ish title, content, allowed_mentions)
fail_plan = {}     # url -> list of codes/exceptions to return before success

class Resp:
    def __init__(self, code): self.status_code = code

class FakeWH:
    def __init__(self, url, **kw):
        self.url, self.kw, self.content, self.embeds = url, kw, None, []
    def add_embed(self, e): self.embeds.append(e)
    def add_file(self, **k): pass
    def set_content(self, c): self.content = c
    def execute(self):
        plan = fail_plan.get(self.url)
        if plan:
            step = plan.pop(0)
            if isinstance(step, Exception): raise step
            if step >= 400: return Resp(step)
        sent.append((self.embeds[0].title if self.embeds else None, self.content, self.kw.get("allowed_mentions")))
        return Resp(204)

engine.DiscordWebhook = FakeWH
engine.WebhookSender.RETRY_DELAYS = (0, 0, 0)
URL = "https://discord.com/api/webhooks/1/abc"

def new_engine(name):
    cfg = engine.Config(os.path.join(TMP, name + ".ini"))
    cfg.set_webhooks([{"name": "t", "url": URL, "enabled": True}])
    return cfg, engine.DetectionEngine(cfg)

def titles(): return [t for t, _, _ in sent]
def ok(name): print("  ok  ", name)

# 2. removing a user/role also removes it from per-biome overrides
cfg.set_mention_users([{"id": "111"}, {"id": "222"}]); cfg.set_mention_roles([{"id": "9"}])
cfg.set_mention_per_biome({"heaven": {"users": ["111", "222"], "roles": ["9"]}})
cfg.set_mention_users([{"id": "111"}]); cfg.set_mention_roles([])
assert cfg.get_mention_per_biome()["heaven"] == {"users": ["111"], "roles": []}
ok("mention pruning")

# 3. queue: retries then succeeds; permanent errors are not retried; flush waits
sent.clear(); cfg, eng = new_engine("b")
fail_plan[URL] = [500, ConnectionError("down")]
eng._submit(FakeWH(URL), URL, "x"); assert eng.sender.flush(3)
assert len(sent) == 1 and eng.sender.status[URL]["ok"], "should succeed after retries"
sent.clear(); fail_plan[URL] = [404, 404, 404]
eng._submit(FakeWH(URL), URL, "x"); eng.sender.flush(3)
assert not sent and fail_plan[URL] == [404, 404] and not eng.sender.status[URL]["ok"], "404 must not retry"
ok("webhook queue retry / permanent error")

# 4. state machine: RPC vs OCR, dedupe, grace window, biome -> biome
sent.clear(); fail_plan.clear(); cfg, eng = new_engine("c")
eng.stats.start_session()
assert eng._apply_event("WINDY", "rpc")
assert not eng._apply_event("WINDY", "ocr")                 # duplicate
assert not eng._apply_event("SNOWY", "ocr")                 # inside grace: HUD may lag
eng._last_rpc_ts -= engine.OCR_RPC_GRACE + 1
assert eng._apply_event("SNOWY", "ocr")                     # Randomizer-style change seen only by OCR
assert not eng._apply_event("SNOWY", "rpc")                 # RPC catching up later: no duplicate
assert eng._apply_event("NORMAL", "rpc")
eng.sender.flush(3)
assert titles() == ["✧  Windy", "Windy — Ended", "✧  Snowy", "Snowy — Ended"], titles()
assert eng.stats.counts == {"WINDY": 1, "SNOWY": 1}
ok("state machine rpc/ocr")

# 5. OCR text matching
names = list(engine.BIOME_COLORS)
cases = {"[ WINDY ]": "WINDY",
         "GL1TCHED": "GLITCHED", "GLITCHEO": "GLITCHED", "CYBERSPAGE": "CYBERSPACE",
         "SINGULARITY": "SINGULARITY", "WELL": None, "HELI": None, "random words": None, "": None}
for text, want in cases.items():
    got, _ = ocr.match_biome([text], names)
    assert got == want, (text, got, want)
assert ocr.match_biome(["junk", "x NULL y"], names)[0] == "NULL"
assert ocr.match_biome(["WINDY SNOWY RAINY"], names)[0] is None      # a list of biomes is not the game
assert ocr.match_biome(["RAINY"], names) == ("RAINY", 1.0)
ok("ocr matching")

# 6. full loop on fake log files: mid-biome start, live changes, pause, crash/close
logdir = tempfile.mkdtemp(); logf = os.path.join(logdir, "a.log")
def rpc(b): return '2026-10-05T10:00:00 {"command":"SetRichPresence","data":{"largeImage":{"hoverText":"%s"}}}\n' % b
open(logf, "w").write("noise\n" + rpc("NORMAL") + rpc("GLITCHED"))
alive = {"v": "player"}
engine.detect_roblox_version = lambda: alive["v"]
engine.get_log_dir = lambda v: logdir
sent.clear(); cfg, eng = new_engine("d")
events = []
eng.on_biome = lambda e, a: events.append((e, a))
eng.start()
def rpc(b): return '2026-10-05T10:00:00.000Z,1.0,1 [FLog::Output] [BloxstrapRPC] {"command":"SetRichPresence","data":{"largeImage":{"hoverText":"%s"}}}\n' % b
def wait(cond, t=5):
    end = time.time() + t
    while time.time() < end and not cond(): time.sleep(0.05)
    return cond()
assert wait(lambda: ("GLITCHED", "started") in events), "mid-biome start must be detected"
with open(logf, "a") as f: f.write(rpc("NORMAL"))
assert wait(lambda: ("GLITCHED", "ended") in events)
eng.pause(); time.sleep(0.3)
with open(logf, "a") as f: f.write(rpc("HELL"))        # happens while paused
time.sleep(0.6); n = len(events)
eng.pause()                                              # resume
with open(logf, "a") as f: f.write(rpc("NORMAL"))
time.sleep(0.6)
assert len(events) == n, "nothing sent for a biome that came and went during pause: %s" % events
with open(logf, "a") as f: f.write('{"command":"SetRichPresence","data":')   # half-written line
time.sleep(0.4)
with open(logf, "a") as f: f.write('{"largeImage":{"hoverText":"RAINY"}}}\n')
assert wait(lambda: ("RAINY", "started") in events), "partial line must be completed, not lost"
d = eng.diagnostics(); assert d["roblox"] == "player" and d["current"] == "RAINY" and d["webhooks"][0]["name"] == "t"
alive["v"] = None                                       # Roblox closes mid-biome
assert wait(lambda: ("RAINY", "ended") in events)
assert eng.store.crashes_since(7) == 1
eng.stop()
assert any("Session Summary" in t for t in titles()) and any("Macro Stopped" in t for t in titles())
ok("detection loop (mid-biome start, pause, partial line, disconnect, stop flush)")

# 7. config in a user data dir + legacy values survive
assert os.path.isdir(engine.DATA_DIR) and engine.CONFIG_PATH.startswith(engine.DATA_DIR)
c = engine.Config(os.path.join(TMP, "e.ini")); assert c.get_ocr()["enabled"] is True and c.get_ocr()["auto"] is True and c.get_ocr()["calibrated"] is False
c.set_ocr({"enabled": True, "left": 0.1, "top": 0.8, "width": 5, "height": 0.1, "interval": 99})
o = c.get_ocr(); assert o["enabled"] and o["width"] <= 0.9 and o["interval"] == 5.0, o
ok("config / ocr settings clamped")

# 8. the exact lines from a real F9 console / log are understood (as in the user's screenshot)
real = ('2026-10-05T03:18:06.512Z,1234.5,1c4 [FLog::Output] [BloxstrapRPC] {"command":"SetRichPresence","data":'
        '{"state":"Equipped _None_","smallImage":{"hoverText":"Sol\' RNG","assetId":99330552067662},'
        '"largeImage":{"hoverText":"WINDY","assetId":138169499467564}}}')
assert engine.DetectionEngine._parse_rpc_line(real) == "WINDY"
assert engine.DetectionEngine._parse_rpc_line(real.replace("WINDY", "NORMAL")) == "NORMAL"
assert engine.DetectionEngine._parse_rpc_line("03:15:00 -- [ReplicaIY] ReplicatedFirst warning") is None
lf = os.path.join(tempfile.mkdtemp(), "x.log")
open(lf, "w").write("noise\n" + real + "\n" + real.replace("WINDY", "NORMAL") + "\n" + real.replace("WINDY", "RAINY") + "\n")
cfg, eng = new_engine("f")
feed = eng._tail_events(lf)
assert [c["event"] for c in feed] == ["RAINY", "NORMAL", "WINDY"] and feed[0]["time"], feed
engine.get_latest_log_file = lambda d, current=None: lf                 # macro NOT started: panel still works
engine.detect_roblox_version = lambda: "player"
d = eng.diagnostics()
assert d["roblox"] == "player" and d["log_path"] == "x.log" and d["console"][0]["event"] == "RAINY"
ok("F9-style lines parsed + console feed works with the macro stopped")

# 9. auto-find: locate the biome text anywhere and derive the zone (fake capture + fake OCR)
from PIL import Image
import types
ocr.capture = lambda region: (Image.new("RGB", (1920, 1080), (10, 10, 20)), "")
def fake_recognize(img, lang="en"):
    sc = img.width / 1920
    word = lambda t, x, y, w, h: {"text": t, "bounding_rect": {"x": x * sc, "y": y * sc, "width": w * sc, "height": h * sc}}
    lines = [{"text": "NIGHTTIME", "words": [word("NIGHTTIME", 20, 880, 120, 24)]},
             {"text": "[ WINDY ]", "words": [word("[", 30, 820, 10, 24), word("WINDY", 50, 820, 90, 24), word("]", 145, 820, 10, 24)]}]
    return {"text": "NIGHTTIME [ WINDY ]" if img.width >= 1800 else "", "lines": lines}   # the small HUD-zone probe reads nothing: the scan must find it
sys.modules["winocr"] = types.SimpleNamespace(recognize_pil_sync=fake_recognize)
r = ocr.find_biome_text(names)
assert r["ok"] and r["match"] == "WINDY", r
rg = r["region"]
x0, y0, x1, y1 = rg["left"] * 1920, rg["top"] * 1080, (rg["left"] + rg["width"]) * 1920, (rg["top"] + rg["height"]) * 1080
assert x0 <= 50 and x1 >= 140 and y0 <= 820 and y1 >= 844, rg      # box fully inside the zone
assert 0 <= rg["left"] and rg["left"] + rg["width"] <= 1 and rg["top"] + rg["height"] <= 1
assert r["image"].startswith("data:image/png;base64,")
sys.modules["winocr"] = types.SimpleNamespace(recognize_pil_sync=lambda img, lang="en": {"text": "x", "lines": [{"text": "NIGHTTIME", "words": []}]})
r2 = ocr.find_biome_text(names)
assert not r2["ok"] and "No biome name" in r2["error"] and r2["image"]
ok("auto-find zone (found / not found)")

# 10. normal user, zero setup: Start -> zone found by itself -> biome seen by OCR only
#     -> real webhook -> NOT ended by a few unreadable frames
class FakeOcr:
    def __init__(self): self.reads, self.finds, self.calls = [], 0, []
    def find_biome_text(self, names, avoid_title=None, expect=None):
        self.finds += 1
        if self.finds == 1:
            return {"ok": False, "error": "No biome name found on screen.", "seen": ["NIGHTTIME"]}
        return {"ok": True, "match": "NORMAL", "seen": [], "region": {"left": 0.02, "top": 0.70, "width": 0.2, "height": 0.08}}
    def read_biome(self, cfg, names, avoid_title=None):
        self.calls.append((cfg["left"], cfg["top"], avoid_title))
        r = self.reads.pop(0) if self.reads else {"match": None, "text": "", "score": 0.0, "error": ""}
        return dict({"text": r.get("match") or "", "score": 1.0, "error": ""}, **r)
engine.OCR_SCAN_EVERY = 0.0
engine.OCR_FAILSAFE_FACTOR, engine.OCR_FAILSAFE_PAD = 0.01, 0.0   # GLITCHED (164 s) -> safety net after 1.6 s in this test
fake = FakeOcr(); engine.ocr_mod = fake
sent.clear(); fail_plan.clear()
cfg, eng = new_engine("g")
cfg.set_ocr({"interval": 0.2})
eng.stats.start_session(); eng._roblox_version = "player"; eng._gen = 1; eng._stop_flag.clear()
eng._last_rpc_ts = time.time() - 60                       # Rich Presence silent (Strange Controller case)
assert cfg.get_ocr()["enabled"] and not cfg.get_ocr()["calibrated"]
# a fuzzy read (misread letters) needs more confirmations than an exact one
fake.reads = [{"match": "GLITCHED"}, {"match": "GLITCHED"}] + [{"match": None}] * 4 + [{"match": "GLITCHED"}]
th = threading.Thread(target=eng._ocr_loop, args=(1,), daemon=True); th.start()
assert wait(lambda: cfg.get_ocr()["calibrated"], 6), "zone must be locked automatically"
assert cfg.get_ocr()["top"] == 0.70 and fake.finds == 2
assert wait(lambda: eng._last_event == "GLITCHED", 6), "OCR-only biome must be detected"
assert fake.calls and fake.calls[0][2] == engine.OWN_TITLE and fake.calls[0][1] == 0.70   # saved zone, avoids our window
assert wait(lambda: not fake.reads, 6)                    # 4 unreadable frames, then it is read again
time.sleep(0.25)
assert eng._last_event == "GLITCHED" and "Glitched — Ended" not in titles(), "unreadable frames must NOT end a biome"
eng.sender.flush(3)
assert titles()[-1].lower().startswith("✦  glitched") and "RARE" in titles()[-1]
assert wait(lambda: eng._last_event == "NORMAL", 8), "long absence ends an OCR-only biome"
eng.sender.flush(3)
assert titles()[-1] == "Glitched — Ended", titles()
assert eng.source_stats["ocr"]["first"] == 1
eng._stop_flag.set(); th.join(2)
ok("zero-setup OCR: auto zone, detect, no false end, long-absence end")

# 10b. fuzzy reads need 4 identical reads; exact need 2
sent.clear(); cfg, eng = new_engine("g2"); cfg.set_ocr({"interval": 0.2, "calibrated": True})
eng.stats.start_session(); eng._roblox_version = "player"; eng._gen = 1; eng._stop_flag.clear()
eng._last_rpc_ts = time.time() - 60
fz = FakeOcr(); fz.reads = [{"match": "WINDY", "score": 0.9}] * 3 + [{"match": None}]; engine.ocr_mod = fz
th = threading.Thread(target=eng._ocr_loop, args=(1,), daemon=True); th.start()
assert wait(lambda: not fz.reads, 6); time.sleep(0.15)
assert eng._last_event is None, "3 fuzzy reads are not enough"
fz.reads = [{"match": "WINDY", "score": 0.9}] * 4
assert wait(lambda: eng._last_event == "WINDY", 6)
eng._stop_flag.set(); th.join(2)
ok("hysteresis: fuzzy 4 reads / exact 2")

# 10c. two sources, one message: confirmations are scored, never re-sent; same message never twice
sent.clear(); cfg, eng = new_engine("g3"); eng.stats.start_session()
assert eng._apply_event("WINDY", "ocr")                   # OCR first (Biome Randomizer)
time.sleep(0.05)
assert not eng._apply_event("WINDY", "rpc")               # the log confirms later -> no second message
eng.sender.flush(3)
assert titles() == ["✦  Windy"] or len(titles()) == 1, titles()
assert eng.source_stats["ocr"]["first"] == 1 and eng.source_stats["ocr"]["lead_s"] > 0
sent.clear(); eng._sent_guard.clear()
eng._send_biome_webhook("SNOWY", "started"); eng._send_biome_webhook("SNOWY", "started")
eng.sender.flush(3); assert len(sent) == 1, "identical message within the guard window must be dropped"
ok("no duplicate messages across sources")

# 10d. direct WinRT path (mocked): used first, frame reuse, variant memory, graceful fallback
import types, asyncio, threading as _th
calls = {"n": 0, "script": []}
class _Eng:
    async def recognize_async(self, bm):
        calls["n"] += 1
        if calls.get("boom"): raise RuntimeError("winrt exploded")
        t = calls["script"].pop(0) if calls["script"] else ""
        return types.SimpleNamespace(text=t, lines=[])
class _W:
    def write_bytes(self, b): pass
    def detach_buffer(self): return b""
mods = {
    "winrt": types.ModuleType("winrt"), "winrt.windows": types.ModuleType("winrt.windows"),
    "winrt.windows.media": types.ModuleType("m"), "winrt.windows.media.ocr": types.SimpleNamespace(OcrEngine=types.SimpleNamespace(
        is_language_supported=lambda l: True, try_create_from_language=lambda l: _Eng())),
    "winrt.windows.globalization": types.SimpleNamespace(Language=lambda c: c),
    "winrt.windows.storage": types.ModuleType("s"), "winrt.windows.storage.streams": types.SimpleNamespace(DataWriter=_W),
    "winrt.windows.graphics": types.ModuleType("g"), "winrt.windows.graphics.imaging": types.SimpleNamespace(
        SoftwareBitmap=types.SimpleNamespace(create_copy_from_buffer=lambda b, f, w, h: object()),
        BitmapPixelFormat=types.SimpleNamespace(RGBA8=1)),
}
saved = {k: sys.modules.get(k) for k in mods}; sys.modules.update(mods)
ocr._tls = _th.local()
rd = ocr.get_reader(); assert rd.fast and rd.path == "fast"
img = Image.new("RGB", (300, 60), (0, 0, 0))
calls["script"] = ["", "[ RAINY ]"]                       # 1st variant reads nothing, 2nd reads the biome
r = ocr.read_image(img, names)
assert r["match"] == "RAINY" and r["variant"] == "value_inv" and not r["reused"] and calls["n"] == 2, (r, calls)
assert ocr._zone_cache().best == "value_inv"
n0 = calls["n"]; r = ocr.read_image(img, names)           # identical pixels: no OCR at all
assert r["reused"] and r["match"] == "RAINY" and calls["n"] == n0
img2 = Image.new("RGB", (300, 60), (255, 255, 255)); calls["script"] = ["WINDY"]
r = ocr.read_image(img2, names); assert r["match"] == "WINDY" and calls["n"] == n0 + 1   # best variant tried first
calls["boom"] = True                                      # WinRT breaks -> winocr fallback, no crash
sys.modules["winocr"] = types.SimpleNamespace(recognize_pil_sync=lambda im, lang="en": {"text": "SNOWY", "lines": []})
r = ocr.read_image(Image.new("RGB", (300, 60), (90, 10, 10)), names)
assert r["match"] == "SNOWY" and r["path"] == "winocr" and not ocr.get_reader().fast
for k, v in saved.items():
    if v is None: sys.modules.pop(k, None)
    else: sys.modules[k] = v
ocr._tls = _th.local()
ok("OCR engine: fast path, frame reuse, variant memory, fallback")

# 10e. the log reader measures its own delay (Roblox timestamps are UTC)
lag = engine.DetectionEngine._line_lag(time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(time.time() - 2)) + ".000Z,1.0,1 [FLog::Output] x")
assert lag is not None and 1.5 < lag < 3.5, lag
assert engine.DetectionEngine._line_lag("no timestamp here") is None
ok("log delay measurement")

# 11. our own window over the zone is never read
fake2 = FakeOcr(); fake2.reads = [{"match": None, "text": "", "error": "Radiance Macro is covering the OCR zone - move or minimize it."}] * 4
engine.ocr_mod = fake2; sent.clear()
cfg, eng = new_engine("h"); cfg.set_ocr({"interval": 0.5, "calibrated": True})
eng.stats.start_session(); eng._roblox_version = "player"; eng._gen = 1; eng._stop_flag.clear()
th = threading.Thread(target=eng._ocr_loop, args=(1,), daemon=True); th.start()
assert wait(lambda: len(fake2.calls) >= 3, 6); eng._stop_flag.set(); th.join(2)
assert eng._last_event is None and not sent
assert "covering" in eng.ocr_info["error"]
ok("covered zone is skipped, no false biome")

# 12. the log reader never falls behind (the old one read one line per turn and rescanned processes/files each time)
def slow_env(ps=0.03, scan=0.03):
    engine.detect_roblox_version = lambda: (time.sleep(ps), "player")[1]
    ld = tempfile.mkdtemp(); lf = os.path.join(ld, "b.log"); open(lf, "w").write("start\n")
    engine.get_log_dir = lambda v: ld
    engine.get_latest_log_file = lambda d, current=None: (time.sleep(scan), lf)[1]
    return lf
spam = "2026-10-05T10:00:00.000Z,1.0,1 [FLog::Warning] [ReplicaIY] ReplicatedFirst.ClientHandlers.UIs.PrivateServerUI:121 function ReplicaSetValue\n"
lf = slow_env(); sent.clear(); cfg, eng = new_engine("i"); events = []
eng.on_biome = lambda e, a: events.append((e, a)); eng.start(); time.sleep(0.6)
with open(lf, "a") as f:                                  # 300k lines of spam, then three changes in ONE burst
    f.write(spam * 300000)
    f.write(rpc("WINDY") + rpc("NORMAL") + rpc("SNOWY"))
t0 = time.time()
assert wait(lambda: ("SNOWY", "started") in events, 6), "must not lag behind a burst of spam"
assert time.time() - t0 < 3, time.time() - t0
assert events == [("WINDY", "started"), ("WINDY", "ended"), ("SNOWY", "started")], events    # in order, none lost
assert eng.diagnostics()["log_idle_s"] is not None and eng.diagnostics()["log_idle_s"] < 5
eng.stop(); ok("log reader: 300k-line burst, 3 changes in order, no lag")

# 13. macro started mid-biome even when the last Rich Presence line is buried under lots of spam
lf = slow_env(0.0, 0.0)
open(lf, "w").write("noise\n" + rpc("CORRUPTION") + spam * 40000)       # ~6 MB after the last status line
cfg, eng = new_engine("j"); events = []; eng.on_biome = lambda e, a: events.append((e, a)); eng.start()
assert wait(lambda: ("CORRUPTION", "started") in events, 6), "backfill must look far enough back"
eng.stop(); ok("mid-biome start found under 6 MB of log")

# 14. LogTail keeps a half-written line until the rest arrives
p = os.path.join(tempfile.mkdtemp(), "t.log"); open(p, "w").write("old\n")
lt = engine.LogTail(p); assert lt.read_new() == []
with open(p, "a") as f: f.write('{"command":"SetRichPresence","data":{"largeImage":{"hover')
assert lt.read_new() == []
with open(p, "a") as f: f.write('Text":"WINDY"}}}\r\nother\n')
got = lt.read_new(); assert len(got) == 1 and b'WINDY' in got[0] and got[0].endswith(b'}}}\r'), got
lt.close(); ok("LogTail partial lines")

# 15. SolRich-style tolerant parsing: aliases, new biomes, key order, junk
P = engine.parse_rpc_line
mk = lambda hover: '2026 [FLog::Output] [BloxstrapRPC] {"command":"SetRichPresence","data":{"state":"x","smallImage":{"hoverText":"Sol\' RNG"},"largeImage":{"assetId":1,"hoverText":"%s"}}}' % hover
for text, want in {"Sand Storm": "SANDSTORM", "GLITCH": "GLITCHED", "dream space": "DREAMSPACE", "Cyber Space": "CYBERSPACE",
                   "AURORA": "AURORA", "The Citadel of Orders": "THE CITADEL OF ORDERS",
                   "Brand New Biome": "BRAND NEW BIOME", "Sol's RNG": None, "Eon 1": None, "": None}.items():
    assert P(mk(text)) == want, (text, P(mk(text)), want)
assert P('x [BloxstrapRPC] { "command" : "SetRichPresence", "data": { "largeImage": { "hoverText": "Rainy" } } }') == "RAINY"
assert P('[BloxstrapRPC] {"command":"SetRichPresence","data":{"smallImage":{"hoverText":"Sol\' RNG"}}}') is None
assert P("random hoverText line") is None and P("[FLog::Output] nothing here") is None
assert P(mk("Blazing Sun")) is None, "removed biome must be ignored"
ok("tolerant biome parsing (aliases, new biomes, spacing)")

# 16. the log that is really being written wins; studio/installer ignored; no flapping between two live logs
ld = tempfile.mkdtemp(); now = time.time()
def mkf(name, age):
    p = os.path.join(ld, name); open(p, "w").write("x\n"); os.utime(p, (now - age, now - age)); return p
a_ = mkf("0.1_Player_A_last.log", 3); b_ = mkf("0.1_Player_B_last.log", 1)
mkf("0.1_Studio_C_last.log", 0); mkf("Installer_x.log", 0)
assert REAL_LATEST(ld) == b_                     # newest write, Studio/Installer ignored
assert REAL_LATEST(ld, current=a_) == a_         # still being written: do not flap
os.utime(a_, (now - 60, now - 60))
assert REAL_LATEST(ld, current=a_) == b_         # stale: move to the live one
assert REAL_LATEST(tempfile.mkdtemp()) is None
ok("log file choice")

# 17. independent log check catches what the live reader missed (needs two consecutive looks)
lf = os.path.join(tempfile.mkdtemp(), "v.log"); open(lf, "w").write("noise\n" + rpc("WINDY") + "tail noise\n")
cfg, eng = new_engine("l"); eng.stats.start_session(); eng._last_rpc = ("NORMAL", time.time())
assert eng._verify_log(lf) is False and eng._last_event is None        # first look: wait
assert eng._verify_log(lf) is True and eng._last_event == "WINDY"      # second look: catch up
assert eng._verify_log(lf) is False                                    # consistent now
assert eng._log_check["event"] == "WINDY"
ok("log verification")

# 18. all four rare biomes are locked on Ping (Singularity too), whatever the config says
cfg, eng = new_engine("m"); cfg.set("Biomes", "singularity", "message")
for b in ("GLITCHED", "CYBERSPACE", "DREAMSPACE", "SINGULARITY"):
    assert eng._biome_mode(b) == "ping", b
import app as _app
br = _app.Bridge(); before = br._config.get("Biomes", "singularity", fallback=None); br.save_biome_modes({"singularity": "nothing"})
assert br._config.get("Biomes", "singularity", fallback=None) == before
ok("Singularity locked on Ping")

# 19. OCR never ends a biome because text is unreadable; NORMAL read ends it; safety net = real duration
engine.OCR_FAILSAFE_FACTOR, engine.OCR_FAILSAFE_PAD = 1.25, 30.0
cfg, eng = new_engine("n")
assert eng._ocr_failsafe_s("RAINY") == 180.0 and eng._ocr_failsafe_s("SINGULARITY") == 1530.0
assert eng._ocr_failsafe_s("SOMETHING NEW") == engine.OCR_FAILSAFE_UNKNOWN
sent.clear(); cfg.set_ocr({"interval": 0.2, "calibrated": True})
eng.stats.start_session(); eng._roblox_version = "player"; eng._gen = 1; eng._stop_flag.clear(); eng._last_rpc_ts = time.time() - 60
fz = FakeOcr(); engine.ocr_mod = fz
fz.reads = [{"match": "RAINY"}, {"match": "RAINY"}] + [{"match": None}] * 16
th = threading.Thread(target=eng._ocr_loop, args=(1,), daemon=True); th.start()
assert wait(lambda: eng._last_event == "RAINY", 6)
assert wait(lambda: not fz.reads, 8); time.sleep(0.5)
assert eng._last_event == "RAINY" and "Rainy — Ended" not in titles(), "3+ s of unreadable text must not end the biome"
fz.reads = [{"match": "NORMAL"}] * 2
assert wait(lambda: eng._last_event == "NORMAL", 6); eng.sender.flush(3)
assert titles()[-1] == "Rainy — Ended"
eng._stop_flag.set(); th.join(2)
ok("OCR: unreadable never ends a biome, NORMAL does, safety net = real duration")

# 20. windowed <-> fullscreen: the zone is searched again when the window size changes
class FakeOcrWin(FakeOcr):
    def client_size(self): return (1280, 720)
    def find_biome_text(self, names, avoid_title=None, expect=None):
        self.finds += 1
        return {"ok": True, "match": "NORMAL", "seen": [], "client": [1280, 720], "region": {"left": 0.05, "top": 0.8, "width": 0.2, "height": 0.07}}
cfg, eng = new_engine("o"); cfg.set_ocr({"interval": 0.2, "calibrated": True, "ref_w": 1920, "ref_h": 1080, "top": 0.5})
eng.stats.start_session(); eng._roblox_version = "player"; eng._gen = 1; eng._stop_flag.clear()
fw = FakeOcrWin(); engine.ocr_mod = fw
th = threading.Thread(target=eng._ocr_loop, args=(1,), daemon=True); th.start()
assert wait(lambda: cfg.get_ocr()["ref_w"] == 1280 and cfg.get_ocr()["top"] == 0.8, 6), cfg.get_ocr()
assert fw.calls, "keeps reading the old zone while it searches"
eng._stop_flag.set(); th.join(2)
ok("window size change -> zone searched again")

# 21. a truncated / rewritten log does not freeze the reader
p = os.path.join(tempfile.mkdtemp(), "r.log"); open(p, "w").write("A" * 1000 + "\n")
lt = engine.LogTail(p); open(p, "w").write("x\n")
assert lt.read_new() == []
with open(p, "a") as f: f.write(rpc("RAINY"))
assert any(b"RAINY" in l for l in lt.read_new()); lt.close()
ok("LogTail survives truncation")

# 22. no biome hidden inside ordinary text: "Heavenly Potion" must never read as HEAVEN
for text in ["HEAVENLY POTION", "Your 1 Heavenly Potion", "THE AVENUE", "NIGHTTIME", "HEAVENS DOOR POTION"]:
    assert ocr.match_biome([text], names)[0] is None, (text, ocr.match_biome([text], names))
for text, want in {"HEAVEN": "HEAVEN", "[ HEAVEN ]": "HEAVEN", "HEA VEN": "HEAVEN",
                   "THE CITADEL OF ORDERS": "THE CITADEL OF ORDERS", "Sand Storm": "SANDSTORM"}.items():
    assert ocr.match_biome([text], names)[0] == want, (text, ocr.match_biome([text], names))
ok("no biome hidden inside other words")

# 23. THE HEAVEN BUG: a static wrong text reading "HEAVEN" while the log announces real biomes
class StaticOcr:
    def __init__(self, name): self.name, self.calls = name, 0
    def read_biome(self, cfg, names, avoid_title=None):
        self.calls += 1; return {"match": self.name, "score": 1.0, "text": self.name, "error": ""}
    def find_biome_text(self, names, avoid_title=None, expect=None):
        return {"ok": False, "error": "The screen shows Heaven but the log says %s - that is not the biome text, ignored." % (expect or "?").title(), "seen": []}
lf = slow_env(0.0, 0.0); open(lf, "w").write("noise\n" + rpc("WINDY"))
engine.OCR_MISMATCH_S = 1.0; engine.ocr_mod = StaticOcr("HEAVEN"); sent.clear()
cfg, eng = new_engine("p"); cfg.set_ocr({"interval": 0.2, "calibrated": True, "validated": False})
events = []; eng.on_biome = lambda e, a: events.append((e, a)); eng.start()
assert wait(lambda: ("WINDY", "started") in events, 6)
time.sleep(1.2)
with open(lf, "a") as f: f.write(rpc("NORMAL"))
assert wait(lambda: ("WINDY", "ended") in events, 6)
eng._last_rpc_ts -= 20; time.sleep(0.8)                    # well past the RPC grace: the old code announced HEAVEN here
with open(lf, "a") as f: f.write(rpc("RAINY"))
assert wait(lambda: ("RAINY", "started") in events, 6)
eng._last_rpc_ts -= 20; time.sleep(1.2)
assert not any(e == "HEAVEN" for e, _ in events), events
assert engine.ocr_mod.calls > 3
assert wait(lambda: not cfg.get_ocr()["calibrated"], 6), "a zone that contradicts the log must be dropped and searched again"
eng.stop(); eng.sender.flush(3)
assert not any("Heaven" in (t or "") for t in titles()), titles()
ok("static wrong text 'HEAVEN' never announces a biome; wrong zone is dropped")

# 24. a zone that agrees with the log becomes trusted: then OCR may announce what the log never says
lf = slow_env(0.0, 0.0); open(lf, "w").write("noise\n" + rpc("WINDY"))
class ScriptOcr(StaticOcr):
    def __init__(self): super().__init__("WINDY"); self.queue = []
    def read_biome(self, cfg, names, avoid_title=None):
        self.calls += 1
        n = self.queue.pop(0) if self.queue else self.name
        return {"match": n, "score": 1.0, "text": n or "", "error": ""}
so = ScriptOcr(); engine.ocr_mod = so; sent.clear()
cfg, eng = new_engine("q"); cfg.set_ocr({"interval": 0.2, "calibrated": True, "validated": False})
events = []; eng.on_biome = lambda e, a: events.append((e, a)); eng.start()
assert wait(lambda: ("WINDY", "started") in events, 6)
assert wait(lambda: cfg.get_ocr()["validated"], 6), "OCR read what the log says: the zone is proven right"
with open(lf, "a") as f: f.write(rpc("NORMAL"))
assert wait(lambda: ("WINDY", "ended") in events, 6)
eng._last_rpc_ts -= 20; so.name = "RAINY"                  # the log stays silent (Strange Controller style)
assert wait(lambda: ("RAINY", "started") in events, 6), "a verified zone may announce a biome the log never reports"
eng.stop(); ok("verified zone: OCR can announce what the log does not")

# 25. zone search must agree with the log; and a biome the log denies is distrusted
from PIL import Image as _I
ocr.capture = lambda region: (_I.new("RGB", (1920, 1080), (10, 10, 20)), "")
def fake_rec(img, lang="en"):
    sc = img.width / 1920
    wd = lambda t, x, y, w, h: {"text": t, "bounding_rect": {"x": x * sc, "y": y * sc, "width": w * sc, "height": h * sc}}
    return {"text": "x", "lines": [{"text": "Your 1 Heavenly Potion", "words": [wd("Your", 1500, 900, 40, 20), wd("Heavenly", 1550, 900, 90, 20), wd("Potion", 1650, 900, 70, 20)]},
                                   {"text": "[ WINDY ]", "words": [wd("[", 30, 820, 10, 24), wd("WINDY", 50, 820, 90, 24), wd("]", 145, 820, 10, 24)]},
                                   {"text": "HEAVEN", "words": [wd("HEAVEN", 900, 100, 100, 24)]}]}
sys.modules["winocr"] = types.SimpleNamespace(recognize_pil_sync=fake_rec); ocr._tls = _th.local()
r = ocr.find_biome_text(names, expect="WINDY")
assert r["ok"] and r["match"] == "WINDY" and r["validated"] and r["region"]["left"] < 0.1, r      # the HUD text, not the HEAVEN text
r = ocr.find_biome_text(names, expect="RAINY")
assert not r["ok"] and "log says Rainy" in r["error"], r
r = ocr.find_biome_text(names, expect=None); assert r["ok"] and r["match"] in ("WINDY", "HEAVEN") and not r["validated"]
cfg, eng = new_engine("r"); eng.stats.start_session()
eng._apply_event("RAINY", "ocr"); time.sleep(0.05); eng._apply_event("NORMAL", "rpc")
assert eng._ocr_distrust.get("RAINY", 0) > time.time() and eng._ocr_unvalidate
ok("zone search agrees with the log; denied biome is distrusted")

# 26. a zone saved by an older version (never checked against the log) is searched again once
p = os.path.join(tempfile.mkdtemp(), "old.ini")
open(p, "w").write("[OCR]\nenabled = true\ncalibrated = true\nleft = 0.5\ntop = 0.5\nwidth = 0.2\nheight = 0.1\n")
c = engine.Config(p); assert c.get_ocr()["calibrated"] is False and c.get_ocr()["validated"] is False
c.set_ocr({"calibrated": True, "validated": True}); c2 = engine.Config(p)
assert c2.get_ocr()["calibrated"] is True and c2.get_ocr()["validated"] is True      # but only once
ok("old unverified zone is re-searched once")

# 27. the HUD zone really covers the biome line - measured on REAL 1440p screenshots (v4.984)
#     biome line "[ NORMAL ]" y=1205-1227 (of 1439), "v4.984" y=1177-1192, "NIGHTTIME" y=1242-1262, text x=12-127 (up to ~430 for long names)
pr = ocr.preset_region(2559, 1439)
top, bot, right = pr["top"] * 1439, (pr["top"] + pr["height"]) * 1439, pr["width"] * 2559
assert top <= 1205 and bot >= 1227, (top, bot)                 # the whole biome line is inside
assert top >= 1165 and bot <= 1262, (top, bot)                 # but not the currency boxes / far-away text
assert right >= 430 and pr["left"] == 0.0, right               # room for long names like "THE CITADEL OF ORDERS"
for (W, H) in [(1280, 720), (1920, 1080), (2560, 1440), (3840, 2160), (3440, 1440), (5120, 1440), (1024, 768)]:
    z = ocr.preset_region(W, H)
    assert 0 <= z["top"] and z["top"] + z["height"] <= 1 and z["width"] <= 1 and abs(z["top"] * H - 0.8193 * H) < 1, (W, H, z)
    assert abs(z["width"] * W - 0.30 * H) < 2, (W, H, z)       # width follows the height (HUD scales with it)
assert os.path.getsize(os.path.join(ROOT, "tests", "fixtures", "hud_windy_1440p.png")) > 1000
ok("HUD zone covers the real biome line at every resolution")

# 28. 1080p / 1440p / 4K / ultrawide / 32:9: sizes stay inside what Windows OCR accepts, same zone everywhere
assert [round(ocr.text_factor(h), 2) for h in (720, 1080, 1440, 2160)] == [3.0, 2.0, 1.5, 1.0]
assert ocr.scales_for(1920, 1080) == (1.0, 2.0) and ocr.scales_for(2560, 1440) == (1.0, 1.5)
assert ocr.scales_for(3840, 2160) == (1.0,) and ocr.scales_for(5120, 1440) == (1.0,)
fed = []
def res_rec(img, lang="en"):
    fed.append(img.size)
    W = img.width; sc = W / res_rec.W
    if img.width < 1800 * min(1, sc):                          # small zone crops: nothing readable
        return {"text": "", "lines": []}
    wd = lambda t, fx, fy, fw, fh: {"text": t, "bounding_rect": {"x": fx * W, "y": fy * img.height, "width": fw * W, "height": fh * img.height}}
    return {"text": "[ WINDY ]", "lines": [{"text": "[ WINDY ]", "words": [wd("WINDY", 0.02, 0.84, 0.035, 0.017)]}]}
sys.modules["winocr"] = types.SimpleNamespace(recognize_pil_sync=res_rec); ocr._tls = _th.local()
regions = {}
for (W, H) in [(1920, 1080), (2560, 1440), (3840, 2160), (3440, 1440), (5120, 1440)]:
    res_rec.W = W; fed.clear()
    ocr.capture = lambda region, W=W, H=H: (_I.new("RGB", (W, H), (10, 10, 20)), "")
    ocr.region_box = lambda region, W=W, H=H: (0, 0, W, H)
    r = ocr.find_biome_text(names)
    assert r["ok"] and r["match"] == "WINDY", ((W, H), r)
    assert max(max(sz) for sz in fed) <= 10000 and max(a * b for a, b in fed) <= 9_000_000 * 1.2, ((W, H), max(fed))   # engine limit respected
    regions[(W, H)] = r["region"]
for k, z in regions.items():                                   # the zone found sits at the same place, whatever the resolution
    assert 0.0 <= z["left"] < 0.05 and 0.80 < z["top"] < 0.86, (k, z)
ocr.region_box = lambda region: None
ok("1080p / 1440p / 4K / ultrawide / 32:9")

# 29. the known HUD zone is probed first, and must agree with the log
def hud_rec(img, lang="en"):
    return {"text": "[ WINDY ]", "lines": []} if img.width < 1000 else {"text": "", "lines": []}
sys.modules["winocr"] = types.SimpleNamespace(recognize_pil_sync=hud_rec); ocr._tls = _th.local()
ocr.capture = lambda region: (_I.new("RGB", (2560, 1440), (10, 10, 20)), ""); ocr.region_box = lambda region: (0, 0, 2560, 1440)
r = ocr.find_biome_text(names, expect="WINDY")
assert r["ok"] and r["validated"] and r["region"] == ocr.preset_region(2560, 1440), r
r = ocr.find_biome_text(names, expect="RAINY")                  # the HUD says WINDY, the log says RAINY: not accepted
assert not r["ok"], r
ocr.region_box = lambda region: None
ok("HUD zone probed first and checked against the log")

# 30. unreadable at the first enlargement: other enlargements are tried (real crop, thin text)
def size_rec(img, lang="en"): return {"text": "WINDY" if img.height > 150 else "", "lines": []}
sys.modules["winocr"] = types.SimpleNamespace(recognize_pil_sync=size_rec); ocr._tls = _th.local()
zone = _I.new("RGB", (432, 72), (20, 60, 50))
r = ocr.read_image(zone, names, fresh=True, client_h=1440)
assert r["match"] == "WINDY" and r["factor"] == 2.0, r
r2 = ocr.read_image(_I.new("RGB", (432, 72), (60, 60, 20)), names, client_h=1440)   # next frame: straight to what worked
assert r2["match"] == "WINDY" and r2["factor"] == 2.0
del sys.modules["winocr"]; ocr._tls = _th.local()
ok("retries other enlargements, then remembers the one that works")



print("ALL TESTS PASSED")
