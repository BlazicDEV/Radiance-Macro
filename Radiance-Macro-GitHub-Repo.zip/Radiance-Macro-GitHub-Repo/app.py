"""
Radiance Macro - Desktop Host
==============================
Hosts the HTML/CSS/JS UI in a native window (pywebview) and bridges it to
the Python detection engine. Build to a single EXE with build.py / PyInstaller.

Derived from maxstellar's Biome Macro (GPLv3). See COPYING and README.
"""

import os
import sys
import time
import queue
import threading
import webview

from engine import Config, DetectionEngine, DEFAULT_BIOME_MODES, BIOME_COLORS, APP_VERSION, migrate_legacy_files

try:
    import ocr as ocr_mod
except ImportError:
    ocr_mod = None

BASE_DIR = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
UI_INDEX = os.path.join(BASE_DIR, "ui", "index.html")


class Bridge:
    """Exposed to JS as window.pywebview.api.*"""

    def __init__(self):
        migrate_legacy_files()
        self._config = Config()
        # Must stay private (leading underscore). pywebview's js_api
        # injection walks every PUBLIC attribute of the bridge object to
        # build the JS-callable method list. If the native window object
        # is exposed as a public attribute, that walk recurses into the
        # WinForms/EdgeChromium window graph - and native properties like
        # Rectangle.Empty return a new instance on every access, which
        # defeats pywebview's id()-based cycle detection and causes
        # infinite recursion (RecursionError, visible as a wall of
        # ".Empty.Empty.Empty..." in the terminal). This is what was
        # freezing the app immediately on launch.
        self._window = None
        # The detection engine runs on its own background thread and must
        # never touch the webview/JS bridge directly - evaluate_js() is not
        # safe to call off the UI thread on Windows (WebView2/EdgeChromium)
        # and doing so is what causes the app to hang. Instead, engine
        # callbacks push events onto this thread-safe queue, and a small
        # poller running on the UI thread drains it.
        self._event_queue = queue.Queue()
        self._engine = DetectionEngine(
            self._config,
            on_status=lambda s: self._event_queue.put(("status", s)),
            on_biome=lambda e, a: self._event_queue.put(("biome", e, a)),
            on_log=lambda m: self._event_queue.put(("log", m)),
            on_stats=lambda st: self._event_queue.put(("stats", st)),
        )

    def set_window(self, window):
        self._window = window

    # ---- called from JS --------------------------------------------------

    def get_version(self):
        return APP_VERSION

    def get_diagnostics(self):
        return self._engine.diagnostics()

    def get_ocr_config(self):
        return self._config.get_ocr()

    def save_ocr_config(self, cfg):
        if not isinstance(cfg, dict):
            return {"ok": False, "error": "Invalid data."}
        return {"ok": True, "config": self._config.set_ocr(cfg)}

    def _hidden(self, fn):
        """Run `fn` with this window minimized, so a screen capture sees the
        game and not Radiance Macro itself."""
        w = self._window
        try:
            if w:
                w.minimize()
                time.sleep(1.3)
            return fn()
        finally:
            try:
                if w:
                    w.restore()
            except Exception:
                pass

    def find_ocr_zone(self):
        """Scan the whole Roblox window for a biome name and save the zone."""
        if ocr_mod is None:
            return {"ok": False, "error": "OCR module missing."}
        try:
            expect = self._engine.log_biome()   # the zone must read what the log says is active
            res = self._hidden(lambda: ocr_mod.find_biome_text(list(BIOME_COLORS), expect=expect))
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}
        if res.get("ok") and res.get("region"):
            cw, ch = (res.get("client") or [0, 0])[:2]
            self._config.set_ocr(dict(res["region"], calibrated=True, ref_w=cw, ref_h=ch, validated=bool(res.get("validated"))))
        return res

    def test_ocr(self):
        """Capture the configured region once and report what OCR read."""
        if ocr_mod is None:
            return {"ok": False, "error": "OCR module missing."}
        try:
            return self._hidden(lambda: ocr_mod.test_read(self._config.get_ocr(), list(BIOME_COLORS)))
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}

    def get_config(self):
        try:
            return self._config.as_dict()
        except Exception as e:
            # Never let a malformed config crash the whole init sequence on
            # the JS side - fall back to a safe empty shape instead.
            return {
                "Webhook": {"private_server": "", "discord_user_id": "", "webhooks": []},
                "Macro": {"roblox_username": ""},
                "Biomes": dict(DEFAULT_BIOME_MODES),
                "_error": str(e),
            }

    def save_webhook_meta(self, private_server, *_legacy):
        """Saves the private-server link. Extra positional args (the old Discord
        ID fields) are ignored - mentions live in the Mentions tab now."""
        self._config.set('Webhook', 'private_server', private_server or '')
        return {"ok": True}

    def get_mentions(self):
        c = self._config
        return {"users": c.get_mention_users(), "roles": c.get_mention_roles(),
                "per_biome": c.get_mention_per_biome()}

    def _save_mention_list(self, kind, entries):
        c = self._config
        current = c.get_mention_users() if kind == "users" else c.get_mention_roles()
        if not isinstance(entries, list):
            return {"ok": False, "error": "Invalid list.", kind: current}
        if any(isinstance(e, dict) and not str(e.get("id", "")).strip().isdigit() for e in entries):
            return {"ok": False, "error": "Discord IDs are numbers only.", kind: current}
        saved = c.set_mention_users(entries) if kind == "users" else c.set_mention_roles(entries)
        return {"ok": True, kind: saved}

    def save_mention_users(self, entries):
        return self._save_mention_list("users", entries)

    def save_mention_roles(self, entries):
        return self._save_mention_list("roles", entries)

    def save_mention_per_biome(self, mapping):
        if not isinstance(mapping, dict):
            return {"ok": False, "error": "Invalid data."}
        return {"ok": True, "per_biome": self._config.set_mention_per_biome(mapping)}

    def get_webhooks(self):
        return self._config.get_webhooks()

    def add_webhook(self, name, url):
        url = (url or '').strip()
        if "discord" not in url or not url.startswith("https://"):
            return {"ok": False, "error": "That doesn't look like a Discord webhook URL."}
        webhooks = self._config.get_webhooks()
        webhooks.append({
            "name": (name or f"Webhook {len(webhooks) + 1}").strip(),
            "url": url,
            "enabled": True,
        })
        self._config.set_webhooks(webhooks)
        return {"ok": True, "webhooks": webhooks}

    def remove_webhook(self, index):
        webhooks = self._config.get_webhooks()
        if 0 <= index < len(webhooks):
            webhooks.pop(index)
            self._config.set_webhooks(webhooks)
        return {"ok": True, "webhooks": webhooks}

    def toggle_webhook(self, index):
        webhooks = self._config.get_webhooks()
        if 0 <= index < len(webhooks):
            webhooks[index]['enabled'] = not webhooks[index].get('enabled', True)
            self._config.set_webhooks(webhooks)
        return {"ok": True, "webhooks": webhooks}

    def save_biome_modes(self, modes: dict):
        from engine import LOCKED_PING_BIOMES
        for key, mode in modes.items():
            if key in LOCKED_PING_BIOMES:
                continue  # Glitched / Cyberspace / Dreamspace are always Ping, not user-editable
            if key in DEFAULT_BIOME_MODES:
                self._config.set('Biomes', key, mode)
        return {"ok": True}

    def list_biome_icons(self):
        """Filenames available in ui/biome_icons/ for the user to assign
        per biome in the Icons tab."""
        from engine import BIOME_ICONS_DIR
        if not os.path.isdir(BIOME_ICONS_DIR):
            return []
        exts = (".png", ".jpg", ".jpeg", ".webp", ".gif")
        return sorted(f for f in os.listdir(BIOME_ICONS_DIR) if f.lower().endswith(exts))

    def get_biome_icons(self):
        return self._config.get_biome_icons()

    def set_biome_icon(self, key, filename):
        self._config.set_biome_icon(key, filename or "")
        return {"ok": True}

    def save_username(self, username):
        self._config.set('Macro', 'roblox_username', username or '')
        return {"ok": True}

    def get_local_notifications(self):
        return self._config.get('Macro', 'local_notifications', fallback='false') == 'true'

    def set_local_notifications(self, enabled):
        self._config.set('Macro', 'local_notifications', 'true' if enabled else 'false')
        return {"ok": True}

    def test_local_notification(self):
        """Lets the person preview the sound/toast from the Control tab
        without waiting for a real rare biome."""
        import notify
        threading.Thread(
            target=notify.notify_rare_biome, args=("Singularity",), daemon=True
        ).start()
        return {"ok": True}

    def start_macro(self):
        if not self._config.active_webhook_urls():
            return {"ok": False, "error": "Add at least one Discord webhook first."}
        self._engine.start()
        return {"ok": True}

    def pause_macro(self):
        self._engine.pause()
        return {"ok": True}

    def stop_macro(self):
        self._engine.stop()
        return {"ok": True}

    def open_external(self, url):
        import webbrowser
        webbrowser.open(url, new=2, autoraise=True)
        return {"ok": True}

    # ---- engine -> JS, drained on the UI thread only ---------------------

    def poll_events(self):
        """Called from JS on a timer, on the UI thread — the only safe
        place to touch anything webview-related after engine callbacks
        fire from a background thread. Bounded so a runaway producer
        can never make this call hang indefinitely."""
        drained = []
        for _ in range(200):  # hard cap per poll, never loop unbounded
            try:
                drained.append(self._event_queue.get_nowait())
            except queue.Empty:
                break
        return [self._event_to_dict(ev) for ev in drained]

    @staticmethod
    def _event_to_dict(ev):
        kind = ev[0]
        if kind == "status":
            return {"type": "status", "status": ev[1]}
        if kind == "biome":
            return {"type": "biome", "event": ev[1], "action": ev[2]}
        if kind == "log":
            return {"type": "log", "message": ev[1]}
        if kind == "stats":
            return {"type": "stats", "stats": ev[1]}
        return {"type": "unknown"}

    def get_sessions(self):
        from engine import RARE_TIER_BIOMES, biome_key
        rows, total_sec, total_rare = [], 0, 0
        all_sessions = self._engine.store.data.get("sessions", [])
        for s in reversed(all_sessions):
            counts = s.get("counts", {})
            rare = sum(n for name, n in counts.items() if biome_key(name) in RARE_TIER_BIOMES)
            dur = max(0, s.get("end", 0) - s.get("start", 0))
            total_sec += dur
            total_rare += rare
            rows.append({"start": s.get("start", 0), "duration": dur, "biomes": sum(counts.values()),
                         "rare": rare, "recovered": bool(s.get("recovered"))})
        hours = total_sec / 3600
        return {"sessions": rows[:30], "session_count": len(rows), "total_hours": round(hours, 1),
                "total_rare": total_rare, "rare_per_hour": round(total_rare / hours, 2) if hours >= 0.1 else 0}

    def get_stats(self):
        """Pull-based snapshot for when the Stats tab is opened, independent
        of the event queue (which only carries deltas as they happen)."""
        return self._engine.stats.as_dict()

    def export_stats_csv(self):
        """Writes the full session history to CSV and lets the person
        pick where to save it via pywebview's native file dialog."""
        import csv
        rows = self._engine.stats.to_csv_rows()
        if len(rows) <= 1:
            return {"ok": False, "error": "No session data to export yet."}

        default_name = time.strftime("radiance-macro-session-%Y%m%d-%H%M%S.csv")
        try:
            result = self._window.create_file_dialog(
                webview.SAVE_DIALOG, save_filename=default_name,
                file_types=("CSV Files (*.csv)",),
            )
        except Exception as e:
            return {"ok": False, "error": f"Could not open save dialog: {e}"}

        if not result:
            return {"ok": False, "error": "cancelled"}
        path = result if isinstance(result, str) else result[0]

        try:
            with open(path, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerows(rows)
        except OSError as e:
            return {"ok": False, "error": f"Could not write file: {e}"}
        return {"ok": True, "path": path}


def keep_process_fast():
    """Windows slows background processes down (power throttling, coarse timers)
    once their window is minimized or hidden behind a fullscreen game. Opt out,
    so the log reader keeps its pace whatever the window state."""
    if os.name != "nt":
        return
    try:
        import ctypes
        from ctypes import wintypes

        class PowerThrottling(ctypes.Structure):
            _fields_ = [("Version", wintypes.ULONG), ("ControlMask", wintypes.ULONG), ("StateMask", wintypes.ULONG)]

        k32 = ctypes.windll.kernel32
        k32.GetCurrentProcess.restype = wintypes.HANDLE
        handle = k32.GetCurrentProcess()
        # EXECUTION_SPEED (0x1) + IGNORE_TIMER_RESOLUTION (0x4) controlled by us, state 0 = throttling OFF
        state = PowerThrottling(1, 0x1 | 0x4, 0)
        k32.SetProcessInformation(handle, 4, ctypes.byref(state), ctypes.sizeof(state))
        k32.SetPriorityClass(handle, 0x8000)  # ABOVE_NORMAL
    except Exception:
        pass


def main():
    keep_process_fast()
    bridge = Bridge()
    window = webview.create_window(
        title=f"Radiance Macro v{APP_VERSION}",
        url=UI_INDEX,
        js_api=bridge,
        width=860,
        height=600,
        resizable=False,
        background_color="#000000",
    )
    bridge.set_window(window)
    threading.Thread(target=bridge._engine.recover_unsent_session, daemon=True).start()
    webview.start()
    bridge._engine.stop()


if __name__ == "__main__":
    main()
