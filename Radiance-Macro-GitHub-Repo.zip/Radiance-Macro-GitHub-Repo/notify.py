"""
Radiance Macro - Local Notifications
=====================================
Plays a sound and shows a native Windows toast notification when a rare
biome is detected, independent of Discord. Useful when the person isn't
looking at Discord at the moment a rare biome hits.

No extra dependencies: winsound is stdlib on Windows, and the toast uses
PowerShell's built-in Windows.UI.Notifications API via subprocess rather
than a third-party package (keeps the EXE small and avoids another
dependency that could break across Windows versions).

Silently does nothing on non-Windows platforms (dev on Mac/Linux, or if
something goes wrong) - a failed notification should never crash or
interrupt detection.
"""
import platform
import subprocess

IS_WINDOWS = platform.system() == "Windows"


def play_alert_sound():
    """Short system beep - as close to a guaranteed no-dependency sound
    as Windows offers. Never raises."""
    if not IS_WINDOWS:
        return
    try:
        import winsound
        winsound.MessageBeep(winsound.MB_ICONASTERISK)
    except Exception:
        pass


def show_toast(title, message):
    """Native Windows toast notification via PowerShell. Runs detached
    and with a short timeout so a slow/broken PowerShell environment
    can't hang the detection thread. Never raises."""
    if not IS_WINDOWS:
        return
    # Escape single quotes for the embedded PowerShell string literals.
    safe_title = (title or "").replace("'", "''")
    safe_message = (message or "").replace("'", "''")
    script = f"""
[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
$template = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02)
$textNodes = $template.GetElementsByTagName('text')
$textNodes.Item(0).AppendChild($template.CreateTextNode('{safe_title}')) | Out-Null
$textNodes.Item(1).AppendChild($template.CreateTextNode('{safe_message}')) | Out-Null
$toast = [Windows.UI.Notifications.ToastNotification]::new($template)
[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('{{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}}\\WindowsPowerShell\\v1.0\\powershell.exe').Show($toast)
"""
    try:
        subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
            timeout=5,
            capture_output=True,
            creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, "CREATE_NO_WINDOW") else 0,
        )
    except Exception:
        pass


def notify_rare_biome(biome_name):
    """Fires both the sound and the toast for a rare biome detection.
    Called from the detection engine on the same thread as detection -
    both underlying calls are short-timeout/non-blocking by design so
    this never meaningfully delays the next log read."""
    play_alert_sound()
    show_toast("Rare biome detected", f"{biome_name.title()} is active right now.")
