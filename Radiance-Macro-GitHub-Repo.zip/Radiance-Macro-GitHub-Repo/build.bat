@echo off
setlocal
cd /d "%~dp0"
py -3 build.py
if errorlevel 1 (
  echo.
  echo Build failed. Check the messages above.
  pause
  exit /b 1
)
echo.
echo Build finished. Look in the dist folder.
pause
