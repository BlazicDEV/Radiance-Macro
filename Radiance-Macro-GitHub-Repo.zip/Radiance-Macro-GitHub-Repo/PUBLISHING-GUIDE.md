# Publishing guide (Windows + GitHub)

## A. Create the normal source repository

1. Sign in to GitHub as `BlazicDEV`.
2. Create a new repository named `Radiance-Macro`.
3. Choose Public if you want the source and GitHub Pages site to be publicly accessible.
4. Do not initialize with extra files if you plan to upload this package as-is (not required, but avoids merge conflicts).
5. Extract `Radiance-Macro-GitHub-Repo.zip`. Upload the *contents* of the extracted folder to the repository root. `README.md`, `app.py`, `engine.py`, `docs/`, and `COPYING` should be visible at the top level.
6. Commit the files to the `main` branch.

## B. Publish the website

1. In the repository, open **Settings**.
2. In the sidebar, open **Pages**.
3. Under **Build and deployment**, set **Source** to **Deploy from a branch**.
4. Select **main** and the **/docs** folder. Click **Save**.
5. Open the Pages section again and click **Visit site** when the deployment is ready. The expected URL is `https://blazicdev.github.io/Radiance-Macro/`.
6. GitHub Pages can take several minutes to publish. If the page is missing, check the repository's Actions tab for the Pages deployment result.

Official docs: https://docs.github.com/en/pages/quickstart

## C. Publish a normal release

1. Build on Windows with `build.bat`.
2. Test the generated executable, including startup and any required WebView2 runtime.
3. In GitHub, choose **Releases → Draft a new release**.
4. Create a tag (for example `v1.0.0`), write a short changelog, and attach only the tested build.
5. Publish the release. The website's release links will then point to the repository's Releases page.

## D. Keep secrets out of GitHub

Do not upload `config.ini`, real webhook URLs, tokens, or personal settings. Only `config.ini.example` belongs in the public repo.

## E. Link your YouTube

The site already links to https://youtube.com/@iiblazicxc and the GitHub profile.
