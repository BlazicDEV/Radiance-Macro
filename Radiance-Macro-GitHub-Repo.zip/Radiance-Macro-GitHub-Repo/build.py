"""Build the standalone Windows executable for Radiance Macro.
Run `python build.py` on a Windows build machine to produce the public standalone EXE.
The resulting EXE includes Python and application dependencies; end users do not need Python.
"""
import importlib
import importlib.util
import os
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
os.chdir(HERE)
APP_NAME = "Radiance Macro"
VERSION = "1.0"
EXE_NAME = f"{APP_NAME} {VERSION}.exe"

def ensure_packages():
    # Build-time dependencies only. These are installed on the developer's machine,
    # not on the end user's machine.
    packages = {
        "PyInstaller": "pyinstaller>=6.0",
        "webview": "pywebview>=4.4",
        "psutil": "psutil>=5.9",
        "discord_webhook": "discord-webhook>=1.3",
        "mss": "mss>=9.0",
        "PIL": "Pillow>=10.0",
        "winocr": "winocr",
    }
    for module, package in packages.items():
        if importlib.util.find_spec(module) is None:
            print(f"[build] Installing build dependency: {package}")
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])
            importlib.invalidate_caches()
    # WinRT is a namespace package; importing these also confirms the OCR bindings
    # are available in the build environment.
    for module in (
        "winrt.windows.media.ocr",
        "winrt.windows.globalization",
        "winrt.windows.storage.streams",
        "winrt.windows.graphics.imaging",
        "winrt.windows.foundation",
        "winrt.windows.foundation.collections",
    ):
        try:
            importlib.import_module(module)
        except Exception as exc:
            raise SystemExit(
                f"[build] Missing Windows OCR binding {module}: {exc}\n"
                "Use 64-bit Windows and install/upgrade winocr in the build environment."
            )

def main():
    if os.name != "nt":
        raise SystemExit("Build this Windows executable on Windows, not on Linux/macOS.")
    ensure_packages()
    import PyInstaller.__main__

    sep = os.pathsep
    args = [
        "app.py",
        f"--name={APP_NAME} {VERSION}",
        "--onefile",
        "--windowed",
        "--noconfirm",
        "--clean",
        "--icon=assets/icon.ico",
        f"--add-data=ui{sep}ui",
        f"--add-data=assets{sep}assets",
        f"--add-data=COPYING{sep}.",
        "--hidden-import=ocr",
        "--hidden-import=notify",
        "--hidden-import=psutil",
        "--collect-all=webview",
        "--collect-all=winocr",
        "--collect-all=PIL",
        "--collect-all=mss",
        "--collect-submodules=winrt",
        "--collect-submodules=clr",
        "--collect-submodules=pythonnet",
    ]
    PyInstaller.__main__.run(args)
    exe = HERE / "dist" / EXE_NAME
    if not exe.exists():
        raise SystemExit(f"[build] Build did not produce expected file: {exe}")
    print(f"\n[build] SUCCESS: {exe}")
    print("[build] The EXE bundles Python and application dependencies; end users do not need Python.")
    print("[build] Test the EXE on a clean Windows machine before publishing.")
    print("[build] WebView2 Runtime may need to be present on the target Windows system.")

if __name__ == "__main__":
    main()
