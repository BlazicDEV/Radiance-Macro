"""
Radiance Macro - on-screen biome OCR (v2)
=========================================
Second, optional detection source next to the Roblox log (the same feed the
F9 console shows). It reads the biome name shown on the Roblox window with
Windows' built-in OCR, so a change is caught even when the log does not
report it - e.g. Biome Randomizer, Strange Controller or Biome Changer.

Fully external: it only looks at pixels on your own screen. Nothing is
injected into the game and no game memory is read.

What makes it fast
  * one persistent Windows OCR engine per thread, fed directly (no per-call
    setup, no result-object walking); `winocr` is only the fallback
  * a tiny fingerprint of the captured zone: if the pixels did not change,
    the previous result is reused and OCR is not run at all
  * the preprocessing variant that worked last is tried first

What makes it readable
  * several variants of the same zone (grayscale, brightest-channel for blue
    or coloured text, local contrast for dark text, inverted) - the first one
    that gives a confident biome name wins

What keeps it honest
  * names of 4 letters or less (NULL, HELL) must match exactly
  * a text containing two different biome names is ambiguous -> ignored
  * the caller also needs several identical reads in a row (see engine.py)

Limit (inherent to screen OCR): the Roblox window must be visible - not
minimized and not covered by another window.

Dependencies (Windows only, imported lazily so the rest of the app still
runs without them): mss, Pillow, winocr (which installs the winrt bindings).
"""
import io
import re
import sys
import time
import base64
import difflib
import threading

IS_WINDOWS = sys.platform == "win32"
INSTALL_HINT = "pip install mss pillow winocr"

# Where Sol's RNG writes the biome: bottom-left, the thin line "[ NORMAL ]" / "[ WINDY ]" between the
# version text ("v4.984") and the time of day ("NIGHTTIME"). Measured on real 1440p screenshots: the text
# is centred at 84.4% of the window height, ~20 px tall at 1440p, always shown (NORMAL too). The zone is a
# little taller than the text on purpose: with more context around it, hard cases (blue text on a green
# floor) read 14 times out of 16 instead of 6. Width is tied to the HEIGHT (HUD scales with it).
HUD_CENTER_Y = 0.8443
HUD_ZONE_H = 0.050
HUD_ZONE_W_PER_H = 0.30


def preset_region(W, H):
    """The HUD zone for a window of W x H pixels, as fractions of the window."""
    return {"left": 0.0, "top": round(HUD_CENTER_Y - HUD_ZONE_H / 2, 4),
            "width": round(min(1.0, HUD_ZONE_W_PER_H * H / max(1, W)), 4), "height": HUD_ZONE_H}


# Typical OCR confusions, applied before matching.
_CONFUSIONS = str.maketrans({"0": "O", "1": "I", "5": "S", "8": "B", "|": "I", "!": "I"})
FUZZY_MIN = 0.85          # below this a fuzzy match is rejected
SAME_FRAME = 3.0          # mean pixel difference (0-255) under which a frame is "unchanged"
VARIANTS = ("gray", "value_inv", "local", "gray_inv")

_tls = threading.local()  # one reader / zone cache per thread (WinRT objects are thread-bound)


# ---------------------------------------------------------------------------
# Windows / screen
# ---------------------------------------------------------------------------

def _physical(fn):
    """Run `fn` with this thread DPI-aware (per-monitor v2): window rectangles and screen
    captures are then both in REAL pixels, at any display scaling (100% on 1080p, 125-150%
    on 1440p, 150-200% on 4K) and whatever the process itself declared. Without it, a
    scaled display would shift/shrink the captured zone."""
    import functools

    @functools.wraps(fn)
    def wrapper(*a, **k):
        old = None
        if IS_WINDOWS:
            try:
                import ctypes
                f = ctypes.windll.user32.SetThreadDpiAwarenessContext
                f.restype, f.argtypes = ctypes.c_void_p, [ctypes.c_void_p]
                old = f(ctypes.c_void_p(-4))          # DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2
            except Exception:
                old = None                            # Windows older than 10 1607: nothing to do
        try:
            return fn(*a, **k)
        finally:
            if old:
                try:
                    f(ctypes.c_void_p(old))
                except Exception:
                    pass
    return wrapper


@_physical
def find_roblox_client_rect():
    """(x, y, w, h) of the Roblox client area in screen pixels, or None."""
    if not IS_WINDOWS:
        return None
    import ctypes
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    hwnd = user32.FindWindowW(None, "Roblox")
    if not hwnd or user32.IsIconic(hwnd):
        return None
    rect = wintypes.RECT()
    if not user32.GetClientRect(hwnd, ctypes.byref(rect)):
        return None
    pt = wintypes.POINT(0, 0)
    user32.ClientToScreen(hwnd, ctypes.byref(pt))
    w, h = rect.right - rect.left, rect.bottom - rect.top
    if w < 200 or h < 200:
        return None
    return pt.x, pt.y, w, h


@_physical
def screen_info():
    """{'w', 'h', 'scale'}: Roblox client size in real pixels and Windows display scaling."""
    rect = find_roblox_client_rect()
    if not rect:
        return None
    scale = None
    try:
        import ctypes
        user32 = ctypes.windll.user32
        hwnd = user32.FindWindowW(None, "Roblox")
        scale = round(user32.GetDpiForWindow(hwnd) / 96.0, 2) if hwnd else None
    except Exception:
        pass
    return {"w": rect[2], "h": rect[3], "scale": scale}


def client_size():
    """(width, height) of the Roblox client area, or None (closed / minimized)."""
    rect = find_roblox_client_rect()
    return (rect[2], rect[3]) if rect else None


@_physical
def own_window_rect(title):
    """Screen rect (l, t, r, b) of OUR window if it is visible, else None."""
    if not IS_WINDOWS or not title:
        return None
    import ctypes
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    hwnd = user32.FindWindowW(None, title)
    if not hwnd or user32.IsIconic(hwnd) or not user32.IsWindowVisible(hwnd):
        return None
    r = wintypes.RECT()
    if not user32.GetWindowRect(hwnd, ctypes.byref(r)):
        return None
    return r.left, r.top, r.right, r.bottom


def _overlaps(box, rect):
    """box = (left, top, width, height); rect = (l, t, r, b)."""
    if not box or not rect:
        return False
    l, t, w, h = box
    return not (l + w <= rect[0] or l >= rect[2] or t + h <= rect[1] or t >= rect[3])


def region_box(region):
    """Screen box (left, top, width, height) of `region`, or None."""
    rect = find_roblox_client_rect()
    if not rect:
        return None
    x, y, w, h = rect
    return (x + int(w * region["left"]), y + int(h * region["top"]),
            max(8, int(w * region["width"])), max(8, int(h * region["height"])))


@_physical
def capture(region):
    """Grab `region` (fractions of the Roblox client area). -> (PIL image, error)."""
    if not IS_WINDOWS:
        return None, "OCR only works on Windows."
    box = region_box(region)
    if not box:
        return None, "Roblox window not found (closed or minimized)."
    try:
        import mss
        from PIL import Image
        with mss.mss() as sct:
            shot = sct.grab({"left": box[0], "top": box[1], "width": box[2], "height": box[3]})
        return Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX"), ""
    except ImportError as e:
        return None, f"Missing package for OCR: {e.name}. Run: {INSTALL_HINT}"
    except Exception as e:
        return None, f"Screen capture failed: {e}"


# ---------------------------------------------------------------------------
# Windows OCR engine (fast direct path, winocr as fallback)
# ---------------------------------------------------------------------------

class OcrReader:
    """Wraps Windows.Media.Ocr. Fast path talks to the WinRT engine directly
    and keeps it alive; if anything about it fails, `winocr` is used instead."""

    def __init__(self, lang="en"):
        self.lang = lang
        self.fast = False
        self.fast_error = ""
        try:
            import asyncio
            from winrt.windows.media.ocr import OcrEngine
            from winrt.windows.globalization import Language
            from winrt.windows.storage.streams import DataWriter
            from winrt.windows.graphics.imaging import SoftwareBitmap, BitmapPixelFormat
            if not OcrEngine.is_language_supported(Language(lang)):
                raise RuntimeError('no OCR language pack: Add-WindowsCapability -Online -Name '
                                   '"Language.OCR~~~en-US~0.0.1.0"')
            self._engine = OcrEngine.try_create_from_language(Language(lang))
            if self._engine is None:
                raise RuntimeError("OcrEngine could not be created")
            self._loop = asyncio.new_event_loop()
            self._DataWriter, self._SoftwareBitmap, self._Fmt = DataWriter, SoftwareBitmap, BitmapPixelFormat
            self.fast = True
        except Exception as e:  # ImportError off-Windows, missing language, API drift...
            self.fast_error = f"{type(e).__name__}: {e}"

    @property
    def path(self):
        return "fast" if self.fast else "winocr"

    def _recognize_fast(self, img, boxes):
        rgba = img if img.mode == "RGBA" else img.convert("RGBA")
        writer = self._DataWriter()
        writer.write_bytes(rgba.tobytes())
        bitmap = self._SoftwareBitmap.create_copy_from_buffer(
            writer.detach_buffer(), self._Fmt.RGBA8, rgba.width, rgba.height)

        async def go():
            return await self._engine.recognize_async(bitmap)
        res = self._loop.run_until_complete(go())
        out = {"text": res.text, "lines": []}
        if boxes:
            for ln in res.lines:
                words = []
                for wd in ln.words:
                    r = wd.bounding_rect
                    words.append({"text": wd.text,
                                  "bounding_rect": {"x": r.x, "y": r.y, "width": r.width, "height": r.height}})
                out["lines"].append({"text": ln.text, "words": words})
        return out

    def recognize(self, img, boxes=False):
        """-> {"text", "lines": [{"text", "words": [{"text", "bounding_rect"}]}]}
        (lines only when boxes=True on the fast path)."""
        if self.fast:
            try:
                return self._recognize_fast(img, boxes)
            except Exception as e:  # never let the fast path take detection down
                self.fast = False
                self.fast_error = f"{type(e).__name__}: {e}"
        import winocr
        r = winocr.recognize_pil_sync(img.convert("RGB"), self.lang)
        return r if isinstance(r, dict) else {"text": getattr(r, "text", ""), "lines": []}


def get_reader():
    if not hasattr(_tls, "reader"):
        _tls.reader = OcrReader()
    return _tls.reader


def reader_info():
    r = get_reader()
    return {"path": r.path, "error": r.fast_error}


# ---------------------------------------------------------------------------
# Preprocessing
# ---------------------------------------------------------------------------

def text_factor(client_h):
    """Enlargement that gives OCR comfortably big letters whatever the resolution: HUD text is
    ~2x at 1080p (the reference), 1.5x at 1440p, 1x at 4K (it is already big there), 3x at 720p."""
    return max(1.0, min(4.0, 2.0 * 1080.0 / max(1.0, float(client_h))))


def scales_for(W, H):
    """Enlargements to try on the WHOLE window: 1x, then the biggest of 1.5x / 2x that stays within
    a pixel budget and the OCR engine's size limit (10 000 px). 1080p -> (1, 2), 1440p -> (1, 1.5),
    4K and 32:9 -> (1,)."""
    ok = [s for s in (1.5, 2.0) if max(W, H) * s <= 6000 and W * H * s * s <= 9_000_000]
    return (1.0,) + ((ok[-1],) if ok else ())


def _variant(img, name, factor, pad=True):
    """One preprocessed copy of `img`, enlarged `factor` times."""
    from PIL import Image, ImageOps, ImageFilter, ImageChops
    if name.startswith("value"):
        base = img.convert("HSV").split()[2]   # brightest channel: keeps blue / coloured text visible
    else:
        base = ImageOps.grayscale(img)
    big = base.resize((max(1, int(round(base.width * factor))), max(1, int(round(base.height * factor)))), Image.LANCZOS)
    if name == "local":
        # local contrast: text differs from its own surroundings, whatever its colour
        blur = big.filter(ImageFilter.GaussianBlur(radius=max(2, big.height // 10)))
        big = ImageOps.invert(ImageOps.autocontrast(ImageChops.difference(big, blur)))
    else:
        big = ImageOps.autocontrast(big, cutoff=1)
        if name.endswith("_inv"):
            big = ImageOps.invert(big)
    if pad:  # OCR engines read better with a margin around the text
        big = ImageOps.expand(big, border=12, fill=big.getpixel((0, 0)))
    return big.convert("RGB")


def _factor(img):
    """Enlargement so the zone is ~150 px tall (2x-4x), width capped for the engine."""
    f = max(2, min(4, -(-150 // max(1, img.height))))
    return max(1, min(f, 4000 // max(1, img.width)))


def _signature(img):
    return img.convert("L").resize((32, 8)).tobytes()


def _sig_diff(a, b):
    return sum(abs(x - y) for x, y in zip(a, b)) / max(1, len(a))


# ---------------------------------------------------------------------------
# Matching
# ---------------------------------------------------------------------------

def match_biome(texts, names):
    """Match OCR output against biome names -> (name or None, score).
    score == 1.0 means the name is there as WHOLE word(s). A name hidden inside a longer word
    never counts ("HEAVENLY POTION" and "THE AVENUE" are not the HEAVEN biome). Fuzzy matches
    (misread letters) must have nearly the same length. Names of 4 letters or less
    (NULL / HELL) must match exactly. Two different biome names in one text is ambiguous
    (a list of biomes, not the HUD) and returns (None, 0.0)."""
    exact, best_name, best = set(), None, 0.0
    for text in texts:
        toks = re.sub(r"[^A-Z ]", " ", (text or "").upper().translate(_CONFUSIONS)).split()
        cands = set(toks)
        for i in range(len(toks) - 1):
            cands.add(toks[i] + " " + toks[i + 1])      # "BLAZING SUN"
            cands.add(toks[i] + toks[i + 1])            # an OCR split like "HEA VEN"
        for i in range(len(toks) - 3):
            cands.add(" ".join(toks[i:i + 4]))          # "THE CITADEL OF ORDERS"
        for name in names:
            if name in cands or name.replace(" ", "") in cands:
                exact.add(name)
        for name in names:
            if len(name) <= 4:
                continue
            for c in cands:
                if abs(len(c) - len(name)) > 1 or name in c or c in name:
                    continue   # "HEAVENS", "WINDYS": another word that merely contains the name, not a misread
                r = difflib.SequenceMatcher(None, c, name).ratio()
                if r > best:
                    best_name, best = name, r
    if len(exact) > 1:
        return None, 0.0
    if exact:
        return next(iter(exact)), 1.0
    return (best_name, best) if best >= FUZZY_MIN else (None, best)


# ---------------------------------------------------------------------------
# Reading the zone
# ---------------------------------------------------------------------------

FULL_RETRY_S = 1.5   # unreadable text: try every variant x enlargement at most this often


class _ZoneCache:
    def __init__(self):
        self.sig, self.result, self.best, self.best_f = None, None, VARIANTS[0], None
        self.last_full = 0.0


def _zone_cache():
    if not hasattr(_tls, "zone"):
        _tls.zone = _ZoneCache()
    return _tls.zone


def read_image(img, names, fresh=False, client_h=None):
    """OCR a captured zone -> {"text", "match", "score", "variant", "reused", "ms", "path"}.
    `client_h` = height of the Roblox window in pixels (sets the enlargement for the resolution)."""
    reader, zc = get_reader(), _zone_cache()
    t0 = time.perf_counter()
    sig = _signature(img)
    if not fresh and zc.sig is not None and zc.result is not None and _sig_diff(sig, zc.sig) < SAME_FRAME:
        return dict(zc.result, reused=True, ms=0, path=reader.path)
    base = text_factor(client_h) if client_h else float(_factor(img))
    base = max(base, min(4.0, 110.0 / max(1, img.height)))     # a thin zone needs bigger letters
    budget = lambda f: max(1.0, min(f, 4000.0 / max(1, img.width), (4_000_000.0 / max(1, img.width * img.height)) ** 0.5))
    grid = [(v, budget(f)) for f in dict.fromkeys([base, 1.0, 2.0]) for v in VARIANTS]
    attempts = [(zc.best, budget(zc.best_f or base))] + grid
    attempts = list(dict.fromkeys((v, round(f, 2)) for v, f in attempts))
    now = time.monotonic()
    if not fresh and now - zc.last_full < FULL_RETRY_S:
        attempts = attempts[:1]          # we just tried everything: only the known-good combination
    else:
        zc.last_full = now
    texts, result = [], None
    for v, f in attempts:
        text = reader.recognize(_variant(img, v, f))["text"].strip()
        if text:
            texts.append(text)
        name, score = match_biome([text], names)
        if name:
            zc.best, zc.best_f = v, f
            result = {"text": text, "match": name, "score": round(score, 2), "variant": v, "factor": f}
            break
    if result is None:
        result = {"text": " | ".join(dict.fromkeys(texts)), "match": None, "score": 0.0, "variant": "", "factor": 0}
    zc.sig, zc.result = sig, result
    return dict(result, reused=False, ms=int((time.perf_counter() - t0) * 1000), path=reader.path)


def read_biome(cfg, names, avoid_title=None):
    """One OCR pass on the configured zone -> read_image() dict plus "error".
    If our own window covers the zone, nothing is read: our UI lists biome
    names and must never be mistaken for the game."""
    empty = {"text": "", "match": None, "score": 0.0}
    if avoid_title and _overlaps(region_box(cfg), own_window_rect(avoid_title)):
        return dict(empty, error="Radiance Macro is covering the OCR zone - move or minimize it.")
    img, err = capture(cfg)
    if img is None:
        return dict(empty, error=err)
    try:
        res = read_image(img, names, client_h=(img.height / max(0.01, cfg['height'])))
    except ImportError as e:
        return dict(empty, error=f"Missing package for OCR: {e.name}. Run: {INSTALL_HINT}")
    except Exception as e:
        return dict(empty, error=f"Windows OCR failed ({type(e).__name__}: {e}). Is an OCR language pack installed?")
    return dict(res, error="")


def test_read(cfg, names):
    """Same as read_biome (without the frame shortcut) plus a PNG preview of
    exactly what was captured, so the zone can be checked visually."""
    img, err = capture(cfg)
    if img is None:
        return {"ok": False, "error": err}
    try:
        res = dict(read_image(img, names, fresh=True, client_h=(img.height / max(0.01, cfg['height']))), error="")
    except Exception as e:
        res = {"text": "", "match": None, "score": 0.0, "error": f"Windows OCR failed ({type(e).__name__}: {e})"}
    preview = img
    if preview.width > 420:
        preview = preview.resize((420, max(1, int(preview.height * 420 / preview.width))))
    buf = io.BytesIO()
    preview.save(buf, format="PNG")
    res["image"] = "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()
    res["ok"] = not res["error"]
    return res


# ---------------------------------------------------------------------------
# Auto-find: locate the biome text anywhere on screen and derive the zone
# ---------------------------------------------------------------------------

def _boxes(res):
    """Yield (text, (x, y, w, h) in OCR pixels) for every OCR word and line."""
    for line in (res or {}).get("lines", []) or []:
        wb = []
        for w in line.get("words", []) or []:
            r = w.get("bounding_rect") or {}
            if all(k in r for k in ("x", "y", "width", "height")):
                wb.append((w.get("text", ""), (r["x"], r["y"], r["width"], r["height"])))
        for t, b in wb:
            yield t, b
        if wb:  # whole line = union of its words (catches two-word biomes)
            x0 = min(b[0] for _, b in wb); y0 = min(b[1] for _, b in wb)
            x1 = max(b[0] + b[2] for _, b in wb); y1 = max(b[1] + b[3] for _, b in wb)
            yield line.get("text", ""), (x0, y0, x1 - x0, y1 - y0)


def find_biome_text(names, avoid_title=None, expect=None):
    """Scan the WHOLE Roblox window, find the biome text and return the zone around it
    (fractions of the window) + a preview with the box drawn.
    `expect` = the biome the Roblox log says is active right now: only text that reads that
    biome is accepted, so the zone cannot lock onto some other text that merely contains a
    biome name. Text under our own window is ignored (it would be our own UI)."""
    full = {"left": 0.0, "top": 0.0, "width": 1.0, "height": 1.0}
    origin = region_box(full)
    own = own_window_rect(avoid_title) if avoid_title else None
    img, err = capture(full)
    if img is None:
        return {"ok": False, "error": err}
    try:
        from PIL import Image, ImageDraw
    except ImportError as e:
        return {"ok": False, "error": f"Missing package for OCR: {e.name}. Run: {INSTALL_HINT}"}
    W, H = img.size
    seen, cands = [], []  # cands: (score, length, (x, y, w, h) in window px, name)
    reader = get_reader()

    # 1) the place where the game really writes the biome (fast: one small zone)
    pr = preset_region(W, H)
    pbox = (int(W * pr["left"]), int(H * pr["top"]), int(W * (pr["left"] + pr["width"])), int(H * (pr["top"] + pr["height"])))
    hidden = own and origin and _overlaps((origin[0] + pbox[0], origin[1] + pbox[1], pbox[2] - pbox[0], pbox[3] - pbox[1]), own)
    if not hidden:
        try:
            pr_read = read_image(img.crop(pbox), names, fresh=True, client_h=H)
        except Exception:
            pr_read = None
        if pr_read and pr_read.get("match") and (expect is None or pr_read["match"] == expect):
            preview = img.copy()
            ImageDraw.Draw(preview).rectangle([pbox[0], pbox[1], pbox[2], pbox[3]], outline=(255, 70, 70), width=max(2, W // 400))
            if preview.width > 560:
                preview = preview.resize((560, max(1, int(preview.height * 560 / preview.width))))
            buf = io.BytesIO()
            preview.save(buf, format="PNG")
            return {"ok": True, "match": pr_read["match"], "validated": bool(expect), "region": pr, "seen": [pr_read["text"]],
                    "client": [W, H], "image": "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()}

    def pool():
        return [c for c in cands if expect is None or c[3] == expect]
    try:
        # small HUD text is often only readable enlarged, some colours only in another channel
        for variant in ("gray", "value_inv"):
            for scale in scales_for(W, H):
                work = _variant(img, variant, scale, pad=False)
                sx = work.width / W
                res = reader.recognize(work, boxes=True)
                for text, (x, y, w, h) in _boxes(res):
                    text = (text or "").strip()
                    if not text:
                        continue
                    if text not in seen and len(seen) < 40:
                        seen.append(text)
                    name, score = match_biome([text], names)
                    if not name or score < 0.9:
                        continue
                    box = (x / sx, y / sx, w / sx, h / sx)
                    if own and origin and _overlaps((origin[0] + box[0], origin[1] + box[1], box[2], box[3]), own):
                        continue
                    cands.append((score, len(name), box, name))
                if pool():
                    break
            if pool():
                break
    except Exception as e:
        return {"ok": False, "error": f"Windows OCR failed ({type(e).__name__}: {e}). Is an OCR language pack installed?"}

    best = max(pool(), key=lambda c: c[:2]) if pool() else None
    preview = img.copy()
    result = {"seen": seen, "client": [W, H]}
    if best:
        _, _, (x, y, w, h), name = best
        pad_x = max(0.03, 0.6 * w / W)
        pad_y = max(0.02, 1.0 * h / H)
        left = max(0.0, x / W - pad_x)
        top = max(0.0, y / H - pad_y)
        width = min(1.0 - left, max(0.12, w / W + 2 * pad_x))
        height = min(1.0 - top, max(0.05, h / H + 2 * pad_y))
        ImageDraw.Draw(preview).rectangle([left * W, top * H, (left + width) * W, (top + height) * H],
                                          outline=(255, 70, 70), width=max(2, W // 400))
        result.update(ok=True, match=name, validated=bool(expect),
                      region={"left": round(left, 4), "top": round(top, 4),
                              "width": round(width, 4), "height": round(height, 4)})
    elif cands and expect:
        other = ", ".join(sorted({c[3] for c in cands}))
        result.update(ok=False, error=f"The screen shows {other.title()} but the log says {expect.title()} - "
                                      "that is not the biome text, ignored.")
    else:
        result.update(ok=False, error="No biome name found on screen. Make sure Roblox is visible "
                                      "and the biome text is shown, then try again.")
    if preview.width > 560:
        preview = preview.resize((560, max(1, int(preview.height * 560 / preview.width))))
    buf = io.BytesIO()
    preview.save(buf, format="PNG")
    result["image"] = "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()
    return result
